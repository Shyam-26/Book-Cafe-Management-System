
  # Book Cafe Management Webapp

  This is a code bundle for Book Cafe Management Webapp. The original project is available at https://www.figma.com/design/gPH32hH06C6GXdvJZeQG8y/Book-Cafe-Management-Webapp.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  