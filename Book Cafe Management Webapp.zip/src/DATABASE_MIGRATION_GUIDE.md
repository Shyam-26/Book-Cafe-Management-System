# Database Migration Guide

## Quick Setup (Recommended)

If you see the red error message about missing tables, follow these steps:

### Step 1: Copy the SQL Script

Click the **"Copy SQL Script"** button in the error message, or copy the entire contents of `/supabase/migrations/schema.sql`.

### Step 2: Open Supabase SQL Editor

1. Go to [Supabase Dashboard](https://supabase.com/dashboard)
2. Select your project
3. Click **"SQL Editor"** in the left sidebar
4. Click **"New query"**

### Step 3: Run the Migration

1. Paste the copied SQL script into the editor
2. Click **"Run"** or press `Cmd/Ctrl + Enter`
3. Wait for the success message: "Success. No rows returned"

### Step 4: Verify Tables Were Created

1. Go to **"Table Editor"** in the left sidebar
2. You should see these 9 tables:
   - `users`
   - `cafe_tables`
   - `menu_items`
   - `books`
   - `orders`
   - `order_items`
   - `payments`
   - `table_waiting_list` ← New
   - `book_requests` ← New

### Step 5: Refresh the Application

Refresh your browser, and the error message should disappear.

---

## Manual Migration (Alternative)

If the quick setup doesn't work, run these commands individually:

### 1. Create Missing Tables

```sql
-- Table waiting list
CREATE TABLE IF NOT EXISTS public.table_waiting_list (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES public.users(id),
  customer_name TEXT NOT NULL,
  party_size INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting', 'notified', 'cancelled', 'seated')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Book requests
CREATE TABLE IF NOT EXISTS public.book_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES public.users(id),
  customer_name TEXT NOT NULL,
  book_id UUID NOT NULL REFERENCES public.books(id),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'served')),
  staff_id UUID REFERENCES public.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 2. Enable Row Level Security

```sql
ALTER TABLE public.table_waiting_list ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.book_requests ENABLE ROW LEVEL SECURITY;
```

### 3. Create RLS Policies

```sql
CREATE POLICY "Allow all for service role" ON public.table_waiting_list FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.book_requests FOR ALL USING (true);
```

### 4. Create Indexes

```sql
CREATE INDEX IF NOT EXISTS idx_table_waiting_list_status ON public.table_waiting_list(status);
CREATE INDEX IF NOT EXISTS idx_book_requests_status ON public.book_requests(status);
```

### 5. Create Update Triggers

```sql
-- Function to update updated_at timestamp (if not exists)
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers
CREATE TRIGGER update_table_waiting_list_updated_at
  BEFORE UPDATE ON public.table_waiting_list
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_book_requests_updated_at
  BEFORE UPDATE ON public.book_requests
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
```

---

## Troubleshooting

### Error: "Could not find the table 'public.table_waiting_list'"

**Solution:** The table hasn't been created yet. Run the migration script above.

### Error: "relation 'public.users' does not exist"

**Solution:** You need to run the full schema script from `/supabase/migrations/schema.sql`, not just the new tables. The `users` table must be created first.

### Error: "policy already exists"

**Solution:** This is harmless. The policy was already created. Continue with the next steps.

### Error: "trigger already exists"

**Solution:** This is harmless. The trigger was already created. Continue with the next steps.

### Tables created but app still shows error

**Solution:** 
1. Hard refresh your browser (`Cmd+Shift+R` or `Ctrl+Shift+F5`)
2. Clear browser cache
3. Check browser console for any other errors

### "Success. No rows returned" - Is this correct?

**Yes!** This is the expected success message for DDL statements (CREATE TABLE, etc.). It means the tables were created successfully.

---

## Verification

To verify everything is set up correctly, run this query in the SQL Editor:

```sql
SELECT 
  table_name,
  (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = t.table_name AND table_schema = 'public') as column_count
FROM information_schema.tables t
WHERE table_schema = 'public'
  AND table_type = 'BASE TABLE'
ORDER BY table_name;
```

You should see 9 tables listed:
- books
- book_requests ✓
- cafe_tables
- menu_items
- order_items
- orders
- payments
- table_waiting_list ✓
- users

---

## Need More Help?

- Check `SETUP_INSTRUCTIONS.md` for complete setup guide
- Check `TROUBLESHOOTING.md` for common issues
- Check `README.md` for database schema details
