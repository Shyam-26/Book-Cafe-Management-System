# Book Cafe Management System

A comprehensive web application for managing a modern book cafe, featuring table reservations, food ordering, book rentals, and real-time order tracking across three distinct user roles.

## 📋 Project Overview

This full-stack application streamlines book cafe operations by providing dedicated interfaces for customers, staff, and managers. Customers can reserve tables, order food, rent books while dining, and make payments. Staff members manage table allotments, food serving, and book distribution through a tabbed dashboard. Managers oversee analytics, inventory, menu pricing, and staff management.

### Key Features

- **Multi-role Authentication**: Separate login flows for customers, staff, and managers
- **Real-time Updates**: Order status changes are immediately reflected across all users
- **Table Management**: Smart reservation system with waiting list functionality
- **Order Tracking**: Detailed status updates (pending → taken → preparing → served)
- **Book Rental Integration**: Seamless book borrowing during dining experience
- **Payment Processing**: Integrated checkout with multiple payment methods
- **Analytics Dashboard**: Comprehensive revenue and order analytics for managers
- **Inventory Management**: Real-time book and menu item tracking

## 🛠️ Tech Stack

### Frontend

#### **React 18 with TypeScript**
- **Why**: Type-safe component development, enhanced developer experience, and better code maintainability
- **Usage**: All UI components are built as functional React components with TypeScript interfaces

#### **Tailwind CSS v4**
- **Why**: Utility-first CSS framework for rapid UI development with consistent design tokens
- **Usage**: Custom design system defined in `/styles/globals.css` with theme variables for colors, spacing, and typography

#### **shadcn/ui Components**
- **Why**: High-quality, accessible, and customizable React components built on Radix UI
- **Usage**: Pre-built UI primitives in `/components/ui/` for buttons, cards, dialogs, forms, and more

#### **Lucide React Icons**
- **Why**: Beautiful, consistent icon set with tree-shaking support
- **Usage**: Icons for navigation, actions, and visual indicators throughout the app

### Backend

#### **Supabase**
- **Why**: Complete backend-as-a-service with authentication, PostgreSQL database, and edge functions
- **Components Used**:
  - **Supabase Auth**: Role-based user authentication with email/password
  - **PostgreSQL Database**: Relational database with 9 normalized tables
  - **Edge Functions**: Hono-based API server for business logic

#### **Hono Framework**
- **Why**: Lightweight, fast web framework for Edge Functions with excellent TypeScript support
- **Usage**: RESTful API endpoints in `/supabase/functions/server/index.tsx`

#### **PostgreSQL**
- **Why**: Robust relational database with ACID compliance, perfect for transactional operations
- **Schema**: 9-table normalized design (users, cafe_tables, menu_items, books, orders, order_items, payments, table_waiting_list, book_requests)

## 📁 Project Structure

```
├── App.tsx                          # Main application entry point
├── components/
│   ├── HomePage.tsx                 # Landing page with role selection
│   ├── LoginPage.tsx               # Authentication component
│   ├── customer/                   # Customer-specific components
│   │   ├── CustomerDashboard.tsx   # Main customer interface
│   │   ├── TableReservation.tsx    # Table booking with waiting list
│   │   ├── MenuOrdering.tsx        # Food ordering interface
│   │   ├── Checkout.tsx            # Payment processing
│   │   └── OrderHistory.tsx        # Past orders and tracking
│   ├── staff/                      # Staff-specific components
│   │   ├── StaffDashboard.tsx      # Tabbed staff interface
│   │   ├── TableAllotment.tsx      # Table management
│   │   ├── FoodServing.tsx         # Order fulfillment
│   │   ├── BookServing.tsx         # Book distribution
│   │   └── RequestsManagement.tsx  # Waiting list & book requests
│   ├── manager/                    # Manager-specific components
│   │   ├── ManagerDashboard.tsx    # Manager main interface
│   │   ├── Analytics.tsx           # Revenue and order analytics
│   │   ├── MenuManagement.tsx      # Menu item CRUD operations
│   │   ├── BookManagement.tsx      # Book inventory control
│   │   └── StaffList.tsx           # Staff member management
│   └── ui/                         # shadcn/ui component library
├── supabase/
│   ├── functions/server/
│   │   ├── index.tsx               # Hono API server
│   │   └── kv_store.tsx            # Key-value storage utilities
│   └── migrations/
│       ├── schema.sql              # Database table definitions
│       └── queries.sql             # Sample data and queries
├── styles/
│   └── globals.css                 # Global styles and design tokens
└── utils/
    └── supabase/
        └── info.tsx                # Supabase configuration
```

## 🔑 Key Components

### Customer Components

#### **CustomerDashboard.tsx**
Main interface for customers with tab navigation for reservations, ordering, and order history.

**Features**:
- Real-time order status updates
- Book rental requests
- Payment processing
- Order history with detailed status tracking

#### **TableReservation.tsx**
Table booking system with smart availability checking.

**Features**:
- Visual table selection (capacity: 2-6 people)
- Real-time availability status
- Automatic waiting list when tables full
- Integration with food ordering

#### **MenuOrdering.tsx**
Food and beverage ordering interface with book rental integration.

**Features**:
- Category-based menu display (Food & Beverages)
- Shopping cart functionality
- Book selection during ordering
- Real-time price calculation

### Staff Components

#### **StaffDashboard.tsx**
Centralized staff interface with three main tabs.

**Features**:
- Table Allotment: Manage table assignments and status
- Food Serving: Order queue with status updates
- Requests Management: Handle waiting list and book requests

#### **FoodServing.tsx**
Order fulfillment system with assignment mechanism.

**Features**:
- Order assignment (one staff per order)
- Status progression: pending → taken → preparing → served
- Real-time updates to customers
- Order item details with quantities

### Manager Components

#### **ManagerDashboard.tsx**
Comprehensive management interface with four main sections.

**Features**:
- Analytics: Revenue tracking and order statistics
- Menu Management: CRUD operations for menu items
- Book Inventory: Stock management with +/- controls
- Staff Management: Add/remove staff members

#### **Analytics.tsx**
Financial and operational insights.

**Features**:
- Total revenue calculation
- Order count and average order value
- Payment method breakdown
- Temporal analytics (daily, weekly, monthly)

## 🗄️ Database Schema

### Core Tables

1. **users** - User accounts with role-based access (customer, staff, manager)
2. **cafe_tables** - Table inventory with capacity and status tracking
3. **menu_items** - Food and beverage catalog with pricing
4. **books** - Book inventory with availability tracking
5. **orders** - Customer orders with status and assignments
6. **order_items** - Individual items within orders
7. **payments** - Transaction records with payment methods
8. **table_waiting_list** - Queue management when tables full
9. **book_requests** - Standalone book rental requests

### Key Relationships

- Orders → Users (customer_id, staff_id)
- Orders → Tables (table_id)
- Orders → Books (book_id for rentals)
- Order Items → Orders → Menu Items
- Payments → Orders → Customers

## 🔐 Authentication & Authorization

### Role-Based Access Control

**Customer Role**:
- Reserve tables and join waiting list
- Order food and rent books
- Track order status in real-time
- Make payments and view history

**Staff Role**:
- Manage table assignments
- Accept and fulfill orders
- Update order status
- Handle waiting list and book requests

**Manager Role**:
- All staff permissions
- View analytics and reports
- Manage menu items and pricing
- Control book inventory
- Add/remove staff members

### Security Features

- Email/password authentication via Supabase Auth
- JWT-based session management
- Server-side role verification
- Protected API endpoints with authorization headers
- Automatic email confirmation for new accounts

## 🚀 API Endpoints

### Authentication
- `POST /make-server-0c99568f/signup` - User registration
- `POST /make-server-0c99568f/signin` - User login
- `GET /make-server-0c99568f/me` - Get current user

### Tables
- `GET /make-server-0c99568f/tables` - List all tables
- `PUT /make-server-0c99568f/tables/:id` - Update table status

### Menu
- `GET /make-server-0c99568f/menu` - Get menu items
- `POST /make-server-0c99568f/menu` - Add menu item (Manager)
- `PUT /make-server-0c99568f/menu/:id` - Update menu item (Manager)
- `DELETE /make-server-0c99568f/menu/:id` - Delete menu item (Manager)

### Books
- `GET /make-server-0c99568f/books` - List books
- `POST /make-server-0c99568f/books` - Add book (Manager)
- `PUT /make-server-0c99568f/books/:id` - Update inventory (Manager)
- `DELETE /make-server-0c99568f/books/:id` - Delete book (Manager)

### Orders
- `GET /make-server-0c99568f/orders` - Get orders (filtered by role)
- `POST /make-server-0c99568f/orders` - Create order
- `PUT /make-server-0c99568f/orders/:id` - Update order status

### Payments
- `POST /make-server-0c99568f/payments` - Process payment

### Analytics
- `GET /make-server-0c99568f/analytics` - Get revenue data (Manager)

### Staff Management
- `GET /make-server-0c99568f/staff` - List staff (Manager)
- `DELETE /make-server-0c99568f/staff/:id` - Remove staff (Manager)

### Waiting List
- `GET /make-server-0c99568f/waiting-list` - Get waiting list
- `POST /make-server-0c99568f/waiting-list` - Add to waiting list
- `PUT /make-server-0c99568f/waiting-list/:id` - Update status

### Book Requests
- `GET /make-server-0c99568f/book-requests` - Get book requests
- `POST /make-server-0c99568f/book-requests` - Create book request
- `PUT /make-server-0c99568f/book-requests/:id` - Update request status

## 💡 Design Decisions

### Why React + TypeScript?
Type safety reduces runtime errors, improves code documentation, and enhances IDE support for faster development.

### Why Supabase?
Eliminates the need for separate backend infrastructure, provides instant PostgreSQL database with admin UI, built-in authentication, and real-time capabilities out of the box.

### Why Tailwind CSS?
Utility-first approach speeds up development, ensures design consistency through design tokens, and generates optimized CSS bundles.

### Why shadcn/ui?
Provides accessible, customizable components that can be modified directly in your codebase rather than being locked into a node_modules package.

### Why Edge Functions with Hono?
Edge functions deploy globally for low latency, Hono provides a lightweight framework perfect for serverless environments, and TypeScript support ensures type safety across the stack.

### Why PostgreSQL?
Relational data model fits the domain perfectly (orders, items, users, tables), supports complex queries for analytics, and ACID transactions ensure data consistency for payments.

## 🎯 Real-Time Features

### Order Status Updates
When staff updates an order status, customers see the change immediately without refreshing. Implemented through:
1. Staff action triggers PUT request to `/orders/:id`
2. Database update occurs
3. Customer polling (every 5s) fetches updated order list
4. UI updates with new status badges

### Table Availability
Real-time table status prevents double bookings:
1. Customer selects available table
2. Order creation marks table as "occupied"
3. Payment completion frees table to "available"
4. Other customers see updated availability

### Inventory Management
Book and menu availability updates instantly:
1. Manager adjusts inventory with +/- buttons
2. Available quantity updates in database
3. Customer views reflect current stock
4. Orders block when inventory depleted

## 📚 Additional Documentation

- **DATABASE_SETUP.md** - Complete database schema and setup instructions
- **SETUP_INSTRUCTIONS.md** - Step-by-step configuration guide
- **QUICK_START.md** - Fast track to running the application
- **TROUBLESHOOTING.md** - Common issues and solutions
- **IMPLEMENTATION_SUMMARY.md** - Technical implementation details
- **NEW_FEATURES.md** - Recent feature additions

## 🔧 Development

### Prerequisites
- Node.js 18+
- Supabase account
- Modern web browser

### Getting Started

1. **Clone and Install**
   ```bash
   npm install
   ```

2. **Configure Supabase**
   - Create a new Supabase project
   - Run migrations from `/supabase/migrations/schema.sql`
   - Update environment variables in `/utils/supabase/info.tsx`

3. **Start Development**
   ```bash
   npm run dev
   ```

4. **Deploy Edge Functions**
   Follow Supabase CLI instructions to deploy `/supabase/functions/server/`

### Environment Variables Required
- `SUPABASE_URL` - Your Supabase project URL
- `SUPABASE_ANON_KEY` - Public anonymous key
- `SUPABASE_SERVICE_ROLE_KEY` - Service role key (server-side only)

## 🚦 Workflow Examples

### Customer Journey
1. Access homepage → Select "Customer" role
2. Sign up or login
3. Reserve table (or join waiting list if full)
4. Browse menu and add items to cart
5. Optionally select book to rent
6. Confirm order
7. Track order status in real-time
8. Complete payment when served
9. View order history

### Staff Workflow
1. Login as staff member
2. **Table Allotment Tab**: Assign customers to tables
3. **Food Serving Tab**: 
   - View pending orders
   - Click "Take Order" (assigns to you)
   - Update status to "Preparing"
   - Mark as "Served" when delivered
4. **Requests Tab**: Handle waiting list and book requests

### Manager Workflow
1. Login as manager
2. **Analytics**: Review daily/weekly revenue
3. **Menu Management**: Add new items or update prices
4. **Book Inventory**: Adjust stock levels
5. **Staff List**: Add new staff or remove members

## 🤝 Contributing

This project follows best practices for:
- Component composition and reusability
- Type safety with TypeScript
- RESTful API design
- Database normalization
- Error handling and validation

## 📄 License

This project is proprietary software developed for book cafe management.

---

**Built with ❤️ using React, TypeScript, Tailwind CSS, and Supabase**
