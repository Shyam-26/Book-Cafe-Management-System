# Troubleshooting Guide

## Common Issues and Solutions

### "Failed to fetch" Error

This error typically occurs when:

1. **Database tables don't exist yet**
   - **Solution**: Run the migration script from `/supabase/migrations/schema.sql` in your Supabase SQL Editor
   - See [SETUP_INSTRUCTIONS.md](SETUP_INSTRUCTIONS.md) for detailed steps

2. **Edge Function not deployed**
   - **Solution**: The Edge Function at `/supabase/functions/server/index.tsx` needs to be deployed
   - Deploy using Supabase CLI or Dashboard

3. **Network/CORS issues**
   - **Solution**: Check your browser console for specific error messages
   - Ensure your Supabase project URL is correct in `/utils/supabase/info.tsx`

### Database Setup Status

The app will automatically check if the database is set up and show a helpful guide if needed.

#### Quick Check:
1. Open browser console (F12)
2. Look for messages like:
   - ✅ "Database configured correctly" = All good
   - ⚠️ "Database tables not set up" = Run migration needed
   - ❌ "Failed to fetch" = Connection or deployment issue

### Empty Data (No tables, menu items, or books showing)

**Cause**: Database migration hasn't been run yet

**Solution**:
1. Copy all contents of `/supabase/migrations/schema.sql`
2. Open Supabase Dashboard → SQL Editor
3. Paste and run the script
4. Refresh your browser

The migration creates:
- 7 tables (users, cafe_tables, menu_items, books, orders, order_items, payments)
- Sample data (6 tables, 8 menu items, 6 books)
- Indexes and security policies

### Authentication Issues

**"Unauthorized" errors**:
- Make sure you're logged in
- Check that your access token hasn't expired
- Try logging out and logging back in

**Can't sign up**:
- Ensure Edge Function is deployed
- Check Supabase Auth is enabled in your project
- Verify email/password requirements are met

### Real-time Updates Not Working

**Orders not updating**:
- Check browser console for subscription errors
- Ensure Row Level Security (RLS) policies are created (done by migration)
- Verify you have a stable internet connection

### Staff/Manager Features Not Working

**"Manager access required" or "Forbidden" errors**:
- Verify your user role in Supabase `users` table
- Roles must be exactly: 'customer', 'staff', or 'manager'
- Check that RLS policies allow your role to access the resource

### Performance Issues

**Slow loading**:
- Check your Supabase region (closer is faster)
- Verify indexes are created (migration does this automatically)
- Check browser console for slow API calls

### Edge Function Deployment

To deploy the Edge Function manually:

```bash
# Install Supabase CLI if needed
npm install -g supabase

# Login to Supabase
supabase login

# Link your project
supabase link --project-ref YOUR_PROJECT_ID

# Deploy the function
supabase functions deploy server
```

Replace `YOUR_PROJECT_ID` with your actual Supabase project ID.

### Checking Logs

**Supabase Dashboard**:
1. Go to your project dashboard
2. Click "Logs" in the sidebar
3. Select "Edge Functions" or "Database"
4. Look for errors around the time of the issue

**Browser Console**:
- Open Developer Tools (F12)
- Check Console tab for errors
- Look for red error messages
- Network tab shows failed requests

### Still Having Issues?

1. **Clear browser cache** and reload
2. **Check all environment variables** are set correctly
3. **Verify Supabase project is active** and not paused
4. **Review migration script** ran successfully without errors
5. **Check Supabase service status** at status.supabase.com

### Getting More Help

When asking for help, provide:
- Error messages from browser console
- Your Supabase project region
- Which role you're logged in as (customer/staff/manager)
- Steps to reproduce the issue
- Screenshot of the error (if visible in UI)

## Prevention Tips

✅ **Always run migrations after cloning** the project
✅ **Deploy Edge Functions** before first use
✅ **Test with all three roles** (customer, staff, manager)
✅ **Check browser console regularly** during development
✅ **Keep Supabase CLI updated** for best compatibility

## Database Reset

If you need to start fresh:

```sql
-- ⚠️ WARNING: This deletes ALL data
DROP TABLE IF EXISTS payments CASCADE;
DROP TABLE IF EXISTS order_items CASCADE;
DROP TABLE IF EXISTS orders CASCADE;
DROP TABLE IF EXISTS book_rentals CASCADE;
DROP TABLE IF EXISTS reservations CASCADE;
DROP TABLE IF EXISTS books CASCADE;
DROP TABLE IF EXISTS menu_items CASCADE;
DROP TABLE IF EXISTS cafe_tables CASCADE;
DROP TABLE IF EXISTS users CASCADE;
```

Then re-run the migration script from `/supabase/migrations/schema.sql`.
