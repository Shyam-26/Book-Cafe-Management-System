# Quick Start Guide

## 🚀 Get Started in 3 Steps

### Step 1: Run Database Migration
```
1. Open Supabase Dashboard → SQL Editor
2. Copy contents of /supabase/migrations/schema.sql
3. Paste and click "Run"
4. Wait for "Success" message
```

### Step 2: Test the Application
```
1. Refresh the application
2. Create a customer account
3. Place a test order
```

### Step 3: Deploy Edge Function (Optional)
If you see persistent errors, deploy the edge function:
```bash
supabase functions deploy server
```

---

## 🎯 What You Get

After running the migration, you'll have:

✅ **6 Tables** - Ready to reserve
✅ **8 Menu Items** - Coffee, pastries, sandwiches
✅ **6 Books** - Ready to rent
✅ **3 User Roles** - Customer, Staff, Manager
✅ **Real-time Updates** - See changes instantly

---

## 🔍 Quick Checks

### Is it working?
Open browser console (F12) and look for:
- ✅ Green: "Database configured correctly"
- ⚠️ Yellow: Warnings but functioning
- ❌ Red: Setup needed

### Still seeing errors?
1. Check [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
2. Verify migration ran successfully
3. Refresh your browser

---

## 📖 More Help

- **Detailed Setup**: [SETUP_INSTRUCTIONS.md](SETUP_INSTRUCTIONS.md)
- **Fix Issues**: [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
- **Technical Details**: [ERROR_HANDLING_IMPROVEMENTS.md](ERROR_HANDLING_IMPROVEMENTS.md)

---

## 🎭 Demo Workflow

### As Customer:
```
1. Sign up → 2. Select table → 3. Order food → 4. Rent book → 5. Checkout
```

### As Staff:
```
1. Sign up → 2. Take order → 3. Start preparing → 4. Mark served
```

### As Manager:
```
1. Sign up → 2. View analytics → 3. Manage inventory → 4. Edit menu
```

---

**Need help?** All error messages include guidance on what to do next!
