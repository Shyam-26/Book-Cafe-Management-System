# Book Cafe Management System - Database Setup

## PostgreSQL Migration Instructions

This application uses PostgreSQL relational database instead of the KV store. Follow these steps to set up your database:

### Step 1: Access Supabase SQL Editor

1. Go to your Supabase project dashboard
2. Navigate to **SQL Editor** in the left sidebar
3. Click **New Query**

### Step 2: Run the Migration Script

Copy and paste the entire contents of `/supabase/migrations/schema.sql` into the SQL Editor and click **Run**.

This will create:
- **Tables**: users, cafe_tables, menu_items, books, orders, order_items, payments
- **Indexes**: For optimized queries
- **Row Level Security**: Policies for secure access
- **Default Data**: Sample tables, menu items, and books
- **Triggers**: Auto-update timestamps

### Step 3: Verify Installation

Run this query to verify all tables were created:

```sql
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
ORDER BY table_name;
```

You should see these tables:
- books
- cafe_tables
- menu_items
- order_items
- orders
- payments
- users

### Step 4: Test the Application

1. Create accounts for different roles (customer, staff, manager)
2. Test the complete workflow:
   - Customer: Select table → Order food → Checkout
   - Staff: Take order → Mark as preparing → Mark as served
   - Manager: View analytics, manage books/menu/staff

## Database Schema Overview

### users
- Stores user profiles for all roles (customer, staff, manager)
- Links to Supabase Auth

### cafe_tables
- Physical tables in the cafe
- Status: available, reserved, occupied

### menu_items
- Food and beverage items
- Categories: Beverages, Desserts, Pastries, Mains

### books
- Books available for rental
- Tracks total and available quantity

### orders
- Customer orders with staff assignment
- Status flow: pending → taken → preparing → served → completed
- Only one staff can take an order (enforced by staff_id)

### order_items
- Individual items in each order
- Links to menu_items

### payments
- Payment records for completed orders

## Key Features Implemented

### 1. Order Assignment System
- Orders start with `status: pending`
- Any staff can view pending orders
- When a staff member clicks "Take Order", the order status changes to `taken` and `staff_id` is set
- Other staff members cannot take the same order (enforced by backend)
- Status progression: pending → taken → preparing → served → completed

### 2. Real-time Updates
- Customer order history updates every 5 seconds
- Staff views refresh every 5 seconds
- Shows assigned staff member on orders
- Status changes are immediately visible to all users

### 3. Table Reservations
- Customers select available tables
- Tables automatically marked as "occupied" when order is placed
- Staff can view all table statuses in real-time
- Tables freed when payment is completed

### 4. Staff Management
- Managers can add new staff members
- Managers can remove staff members
- Staff list shows all active staff

### 5. Status Tracking
- Customers see detailed order status with staff name
- Staff see which orders they've taken
- Real-time status updates across all dashboards

## Useful SQL Queries

### View all orders with customer and staff info
```sql
SELECT 
  o.*,
  c.name as customer_name,
  s.name as staff_name,
  ct.table_number
FROM orders o
LEFT JOIN users c ON o.customer_id = c.id
LEFT JOIN users s ON o.staff_id = s.id
LEFT JOIN cafe_tables ct ON o.table_id = ct.id
ORDER BY o.created_at DESC;
```

### Check table availability
```sql
SELECT table_number, capacity, status
FROM cafe_tables
ORDER BY table_number;
```

### View today's revenue
```sql
SELECT 
  COUNT(*) as total_orders,
  SUM(amount) as total_revenue
FROM payments
WHERE DATE(created_at) = CURRENT_DATE;
```

### Active orders by status
```sql
SELECT 
  status,
  COUNT(*) as count
FROM orders
WHERE status != 'completed'
GROUP BY status;
```

## Troubleshooting

### If tables are missing:
Re-run the migration script from Step 2

### If you get RLS errors:
The service role key bypasses RLS, so this shouldn't happen. If it does, check that you're using `SUPABASE_SERVICE_ROLE_KEY` in the server.

### If default data isn't showing:
Run the INSERT statements from the migration file individually

### To reset the database:
```sql
-- WARNING: This will delete all data!
DROP TABLE IF EXISTS payments CASCADE;
DROP TABLE IF EXISTS order_items CASCADE;
DROP TABLE IF EXISTS orders CASCADE;
DROP TABLE IF EXISTS books CASCADE;
DROP TABLE IF EXISTS menu_items CASCADE;
DROP TABLE IF EXISTS cafe_tables CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- Then re-run the migration script
```

## Environment Variables Required

Make sure these are set in your Supabase environment:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `SUPABASE_DB_URL`

These are automatically configured in Figma Make.
