-- Useful SQL Queries for Book Cafe Management System

-- ============================================
-- VERIFICATION QUERIES (Run after setup)
-- ============================================

-- List all tables created
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
ORDER BY table_name;

-- Check table structures
\d users
\d cafe_tables
\d menu_items
\d books
\d orders
\d order_items
\d payments

-- ============================================
-- DATA INSPECTION QUERIES
-- ============================================

-- View all users by role
SELECT role, COUNT(*) as count
FROM users
GROUP BY role;

-- View all tables with current status
SELECT table_number, capacity, status
FROM cafe_tables
ORDER BY table_number;

-- View all menu items by category
SELECT category, COUNT(*) as item_count
FROM menu_items
GROUP BY category;

-- View book inventory
SELECT title, author, quantity, available_quantity
FROM books
ORDER BY title;

-- ============================================
-- ORDER TRACKING QUERIES
-- ============================================

-- View all orders with complete information
SELECT 
  o.id,
  o.status,
  c.name as customer_name,
  c.email as customer_email,
  s.name as staff_name,
  ct.table_number,
  o.total_amount,
  o.created_at,
  o.updated_at
FROM orders o
LEFT JOIN users c ON o.customer_id = c.id
LEFT JOIN users s ON o.staff_id = s.id
LEFT JOIN cafe_tables ct ON o.table_id = ct.id
ORDER BY o.created_at DESC;

-- View order details with items
SELECT 
  o.id as order_id,
  o.status,
  c.name as customer,
  mi.name as item_name,
  oi.quantity,
  oi.price,
  (oi.quantity * oi.price) as item_total
FROM orders o
JOIN users c ON o.customer_id = c.id
JOIN order_items oi ON o.id = oi.order_id
JOIN menu_items mi ON oi.menu_item_id = mi.id
ORDER BY o.created_at DESC, mi.name;

-- Active orders by status
SELECT 
  status,
  COUNT(*) as count
FROM orders
WHERE status != 'completed'
GROUP BY status
ORDER BY 
  CASE status
    WHEN 'pending' THEN 1
    WHEN 'taken' THEN 2
    WHEN 'preparing' THEN 3
    WHEN 'served' THEN 4
  END;

-- Orders currently assigned to staff
SELECT 
  s.name as staff_name,
  COUNT(*) as active_orders,
  STRING_AGG(o.status, ', ') as statuses
FROM orders o
JOIN users s ON o.staff_id = s.id
WHERE o.status != 'completed'
GROUP BY s.name;

-- ============================================
-- ANALYTICS QUERIES
-- ============================================

-- Today's orders
SELECT 
  COUNT(*) as total_orders,
  SUM(total_amount) as total_revenue,
  AVG(total_amount) as avg_order_value
FROM orders
WHERE DATE(created_at) = CURRENT_DATE;

-- Revenue by day (last 7 days)
SELECT 
  DATE(created_at) as date,
  COUNT(*) as orders,
  SUM(total_amount) as revenue
FROM orders
WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY DATE(created_at)
ORDER BY date DESC;

-- Most popular menu items
SELECT 
  mi.name,
  mi.category,
  SUM(oi.quantity) as times_ordered,
  SUM(oi.quantity * oi.price) as total_revenue
FROM order_items oi
JOIN menu_items mi ON oi.menu_item_id = mi.id
GROUP BY mi.id, mi.name, mi.category
ORDER BY times_ordered DESC;

-- Customer order history
SELECT 
  u.name as customer,
  COUNT(o.id) as total_orders,
  SUM(o.total_amount) as total_spent,
  MAX(o.created_at) as last_order
FROM users u
LEFT JOIN orders o ON u.id = o.customer_id
WHERE u.role = 'customer'
GROUP BY u.id, u.name
ORDER BY total_spent DESC;

-- Staff performance
SELECT 
  s.name as staff_name,
  COUNT(o.id) as orders_handled,
  AVG(EXTRACT(EPOCH FROM (o.updated_at - o.created_at))/60) as avg_handling_time_minutes
FROM users s
LEFT JOIN orders o ON s.id = o.staff_id
WHERE s.role = 'staff' AND o.status = 'completed'
GROUP BY s.id, s.name
ORDER BY orders_handled DESC;

-- Book rental statistics
SELECT 
  b.title,
  b.author,
  b.quantity,
  b.available_quantity,
  (b.quantity - b.available_quantity) as currently_rented,
  COUNT(o.id) as total_rentals
FROM books b
LEFT JOIN orders o ON b.id = o.book_id
GROUP BY b.id, b.title, b.author, b.quantity, b.available_quantity
ORDER BY total_rentals DESC;

-- Table utilization
SELECT 
  ct.table_number,
  ct.capacity,
  COUNT(o.id) as times_used,
  ct.status as current_status
FROM cafe_tables ct
LEFT JOIN orders o ON ct.id = o.table_id
GROUP BY ct.id, ct.table_number, ct.capacity, ct.status
ORDER BY times_used DESC;

-- Payment methods breakdown
SELECT 
  payment_method,
  COUNT(*) as transaction_count,
  SUM(amount) as total_amount
FROM payments
GROUP BY payment_method;

-- ============================================
-- MAINTENANCE QUERIES
-- ============================================

-- Reset all table statuses to available
UPDATE cafe_tables 
SET status = 'available';

-- Reset all book availability
UPDATE books 
SET available_quantity = quantity;

-- Delete old completed orders (older than 30 days)
DELETE FROM orders 
WHERE status = 'completed' 
  AND created_at < CURRENT_DATE - INTERVAL '30 days';

-- Find orphaned orders (no customer)
SELECT * FROM orders 
WHERE customer_id NOT IN (SELECT id FROM users);

-- Find orders stuck in pending state for more than 1 hour
SELECT 
  o.id,
  c.name as customer,
  o.created_at,
  EXTRACT(EPOCH FROM (NOW() - o.created_at))/60 as minutes_pending
FROM orders o
JOIN users c ON o.customer_id = c.id
WHERE o.status = 'pending' 
  AND o.created_at < NOW() - INTERVAL '1 hour'
ORDER BY o.created_at;

-- ============================================
-- DEVELOPMENT/TESTING QUERIES
-- ============================================

-- Create a test customer
INSERT INTO users (id, email, name, role)
VALUES (
  gen_random_uuid(),
  'test.customer@example.com',
  'Test Customer',
  'customer'
);

-- Create a test staff member
INSERT INTO users (id, email, name, role)
VALUES (
  gen_random_uuid(),
  'test.staff@example.com',
  'Test Staff',
  'staff'
);

-- Simulate an order
WITH new_order AS (
  INSERT INTO orders (customer_id, table_id, status, total_amount)
  VALUES (
    (SELECT id FROM users WHERE email = 'test.customer@example.com'),
    (SELECT id FROM cafe_tables WHERE table_number = 1),
    'pending',
    25.50
  )
  RETURNING id
)
INSERT INTO order_items (order_id, menu_item_id, quantity, price)
SELECT 
  new_order.id,
  mi.id,
  2,
  mi.price
FROM new_order, menu_items mi
WHERE mi.name = 'Cappuccino';

-- ============================================
-- BACKUP QUERIES
-- ============================================

-- Export all data to JSON (for backup)
COPY (
  SELECT json_agg(row_to_json(t))
  FROM (SELECT * FROM users) t
) TO '/tmp/users_backup.json';

-- Count all records
SELECT 
  'users' as table_name, COUNT(*) as count FROM users
UNION ALL
SELECT 'cafe_tables', COUNT(*) FROM cafe_tables
UNION ALL
SELECT 'menu_items', COUNT(*) FROM menu_items
UNION ALL
SELECT 'books', COUNT(*) FROM books
UNION ALL
SELECT 'orders', COUNT(*) FROM orders
UNION ALL
SELECT 'order_items', COUNT(*) FROM order_items
UNION ALL
SELECT 'payments', COUNT(*) FROM payments
UNION ALL
SELECT 'table_waiting_list', COUNT(*) FROM table_waiting_list
UNION ALL
SELECT 'book_requests', COUNT(*) FROM book_requests;

-- ============================================
-- WAITING LIST & BOOK REQUESTS QUERIES
-- ============================================

-- View active waiting list
SELECT 
  id,
  customer_name,
  party_size,
  status,
  created_at,
  EXTRACT(EPOCH FROM (NOW() - created_at))/60 as waiting_minutes
FROM table_waiting_list
WHERE status IN ('waiting', 'notified')
ORDER BY created_at ASC;

-- View pending book requests
SELECT 
  br.id,
  br.customer_name,
  b.title as book_title,
  b.author,
  br.status,
  s.name as staff_name,
  br.created_at
FROM book_requests br
LEFT JOIN books b ON br.book_id = b.id
LEFT JOIN users s ON br.staff_id = s.id
WHERE br.status IN ('pending', 'approved')
ORDER BY br.created_at ASC;

-- Waiting list statistics
SELECT 
  status,
  COUNT(*) as count,
  AVG(EXTRACT(EPOCH FROM (updated_at - created_at))/60) as avg_wait_time_minutes
FROM table_waiting_list
GROUP BY status;

-- Book request statistics
SELECT 
  status,
  COUNT(*) as count
FROM book_requests
GROUP BY status;
