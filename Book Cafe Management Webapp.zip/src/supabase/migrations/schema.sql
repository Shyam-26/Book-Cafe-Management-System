-- Book Cafe Management System - PostgreSQL Schema
-- Run these queries in your Supabase SQL Editor

-- Users table (extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('customer', 'staff', 'manager')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Tables in the cafe
CREATE TABLE IF NOT EXISTS public.cafe_tables (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  table_number INTEGER NOT NULL UNIQUE,
  capacity INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'reserved', 'occupied')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.cafe_tables ENABLE ROW LEVEL SECURITY;

-- Menu items
CREATE TABLE IF NOT EXISTS public.menu_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  category TEXT NOT NULL,
  available BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.menu_items ENABLE ROW LEVEL SECURITY;

-- Books available for rent
CREATE TABLE IF NOT EXISTS public.books (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 0,
  available_quantity INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.books ENABLE ROW LEVEL SECURITY;

-- Orders
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES public.users(id),
  table_id UUID NOT NULL REFERENCES public.cafe_tables(id),
  book_id UUID REFERENCES public.books(id),
  staff_id UUID REFERENCES public.users(id),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'taken', 'preparing', 'served', 'completed')),
  total_amount DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Order items (items in each order)
CREATE TABLE IF NOT EXISTS public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  menu_item_id UUID NOT NULL REFERENCES public.menu_items(id),
  quantity INTEGER NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

-- Payments
CREATE TABLE IF NOT EXISTS public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id),
  customer_id UUID NOT NULL REFERENCES public.users(id),
  amount DECIMAL(10, 2) NOT NULL,
  payment_method TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

-- RLS Policies (allow all for service role, restrict for others)
CREATE POLICY "Allow all for service role" ON public.users FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.cafe_tables FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.menu_items FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.books FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.orders FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.order_items FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.payments FOR ALL USING (true);

-- Insert default data
INSERT INTO public.cafe_tables (table_number, capacity, status) VALUES
  (1, 2, 'available'),
  (2, 4, 'available'),
  (3, 2, 'available'),
  (4, 6, 'available'),
  (5, 4, 'available'),
  (6, 2, 'available')
ON CONFLICT (table_number) DO NOTHING;

INSERT INTO public.menu_items (name, description, price, category, available) VALUES
  ('Espresso', 'Strong coffee', 3.50, 'Beverages', TRUE),
  ('Cappuccino', 'Coffee with steamed milk', 4.50, 'Beverages', TRUE),
  ('Green Tea', 'Organic green tea', 3.00, 'Beverages', TRUE),
  ('Chocolate Cake', 'Rich chocolate cake', 5.50, 'Desserts', TRUE),
  ('Croissant', 'Buttery croissant', 3.50, 'Pastries', TRUE),
  ('Caesar Salad', 'Fresh caesar salad', 8.50, 'Mains', TRUE),
  ('Club Sandwich', 'Triple decker sandwich', 9.50, 'Mains', TRUE),
  ('Blueberry Muffin', 'Freshly baked muffin', 4.00, 'Pastries', TRUE)
ON CONFLICT DO NOTHING;

INSERT INTO public.books (title, author, quantity, available_quantity) VALUES
  ('The Great Gatsby', 'F. Scott Fitzgerald', 5, 5),
  ('1984', 'George Orwell', 4, 4),
  ('To Kill a Mockingbird', 'Harper Lee', 3, 3),
  ('Pride and Prejudice', 'Jane Austen', 4, 4),
  ('The Catcher in the Rye', 'J.D. Salinger', 3, 3),
  ('Harry Potter', 'J.K. Rowling', 6, 6)
ON CONFLICT DO NOTHING;

-- Table waiting list (for when tables are full)
CREATE TABLE IF NOT EXISTS public.table_waiting_list (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES public.users(id),
  customer_name TEXT NOT NULL,
  party_size INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting', 'notified', 'cancelled', 'seated')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.table_waiting_list ENABLE ROW LEVEL SECURITY;

-- Book requests (for standalone book reservations)
CREATE TABLE IF NOT EXISTS public.book_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES public.users(id),
  customer_name TEXT NOT NULL,
  book_id UUID NOT NULL REFERENCES public.books(id),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'served')),
  staff_id UUID REFERENCES public.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.book_requests ENABLE ROW LEVEL SECURITY;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON public.orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_staff_id ON public.orders(staff_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON public.order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_payments_customer_id ON public.payments(customer_id);
CREATE INDEX IF NOT EXISTS idx_users_role ON public.users(role);
CREATE INDEX IF NOT EXISTS idx_table_waiting_list_status ON public.table_waiting_list(status);
CREATE INDEX IF NOT EXISTS idx_book_requests_status ON public.book_requests(status);

-- RLS Policies for new tables
CREATE POLICY "Allow all for service role" ON public.table_waiting_list FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.book_requests FOR ALL USING (true);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically update updated_at
CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_table_waiting_list_updated_at
  BEFORE UPDATE ON public.table_waiting_list
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_book_requests_updated_at
  BEFORE UPDATE ON public.book_requests
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
