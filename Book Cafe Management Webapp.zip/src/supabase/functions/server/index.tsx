import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2.39.7';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));
app.use('*', logger(console.log));

const supabaseUrl = Deno.env.get('SUPABASE_URL');
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY');

if (!supabaseUrl || !supabaseServiceKey || !supabaseAnonKey) {
  console.error('Missing Supabase environment variables');
}

// Admin client for privileged operations
const supabase = createClient(
  supabaseUrl || '',
  supabaseServiceKey || ''
);

// Auth client for user authentication
const supabaseAuth = createClient(
  supabaseUrl || '',
  supabaseAnonKey || ''
);

// Health check endpoint
app.get('/make-server-0c99568f/health', (c) => {
  return c.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    supabaseConfigured: !!(supabaseUrl && supabaseServiceKey)
  });
});

// Signup route
app.post('/make-server-0c99568f/signup', async (c) => {
  try {
    const { email, password, name, role } = await c.req.json();

    if (!email || !password || !name || !role) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    if (!['customer', 'staff', 'manager'].includes(role)) {
      return c.json({ error: 'Invalid role' }, 400);
    }

    // Create user in Supabase Auth
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, role },
      email_confirm: true
    });

    if (error) {
      // Check if it's a duplicate email error
      if (error.message.includes('already been registered') || error.status === 422) {
        console.log('Signup attempt with existing email:', email, '- Redirecting to login');
        return c.json({ 
          error: 'An account with this email already exists. Please try logging in instead.',
          errorCode: 'EMAIL_EXISTS'
        }, 400);
      }
      
      console.error('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }

    // Insert user into public.users table
    const { error: insertError } = await supabase
      .from('users')
      .insert({
        id: data.user.id,
        email,
        name,
        role
      });

    if (insertError) {
      console.error('User insert error:', insertError);
      return c.json({ error: 'Failed to create user profile' }, 500);
    }

    return c.json({ 
      success: true, 
      user: { id: data.user.id, email, name, role } 
    });
  } catch (error) {
    console.error('Signup error:', error);
    return c.json({ error: 'Signup failed' }, 500);
  }
});

// Signin route
app.post('/make-server-0c99568f/signin', async (c) => {
  try {
    const { email, password } = await c.req.json();

    if (!email || !password) {
      return c.json({ error: 'Missing email or password' }, 400);
    }

    // Use auth client (with anon key) for user login
    const { data, error } = await supabaseAuth.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      console.error('Signin error:', error);
      return c.json({ error: 'Invalid credentials' }, 401);
    }

    // Get user profile using admin client
    const { data: userData, error: userError } = await supabase
      .from('users')
      .select('*')
      .eq('id', data.user.id)
      .single();

    if (userError || !userData) {
      return c.json({ error: 'User profile not found' }, 404);
    }

    return c.json({
      success: true,
      access_token: data.session.access_token,
      user: userData
    });
  } catch (error) {
    console.error('Signin error:', error);
    return c.json({ error: 'Signin failed' }, 500);
  }
});

// Get current user
app.get('/make-server-0c99568f/me', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No token provided' }, 401);
    }

    // Use auth client to verify token
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: 'Invalid token' }, 401);
    }

    // Use admin client to get user profile
    const { data: userData } = await supabase
      .from('users')
      .select('*')
      .eq('id', user.id)
      .single();

    if (!userData) {
      return c.json({ error: 'User not found' }, 404);
    }

    return c.json({ user: userData });
  } catch (error) {
    console.error('Get user error:', error);
    return c.json({ error: 'Failed to get user' }, 500);
  }
});

// Tables routes
app.get('/make-server-0c99568f/tables', async (c) => {
  try {
    const { data, error } = await supabase
      .from('cafe_tables')
      .select('*')
      .order('table_number');

    if (error) {
      console.error('Get tables error:', error);
      // Return empty array instead of error for better UX
      return c.json({ tables: [], error: error.message });
    }

    return c.json({ tables: data || [] });
  } catch (error) {
    console.error('Get tables error:', error);
    return c.json({ tables: [], error: 'Failed to get tables' });
  }
});

app.put('/make-server-0c99568f/tables/:id', async (c) => {
  try {
    const tableId = c.req.param('id');
    const { status } = await c.req.json();

    const { data, error } = await supabase
      .from('cafe_tables')
      .update({ status })
      .eq('id', tableId)
      .select()
      .single();

    if (error) throw error;

    return c.json({ success: true, table: data });
  } catch (error) {
    console.error('Update table error:', error);
    return c.json({ error: 'Failed to update table' }, 500);
  }
});

// Menu routes
app.get('/make-server-0c99568f/menu', async (c) => {
  try {
    const { data, error } = await supabase
      .from('menu_items')
      .select('*')
      .order('category', { ascending: true });

    if (error) {
      console.error('Get menu error:', error);
      return c.json({ menu: [], error: error.message });
    }

    return c.json({ menu: data || [] });
  } catch (error) {
    console.error('Get menu error:', error);
    return c.json({ menu: [], error: 'Failed to get menu' });
  }
});

app.post('/make-server-0c99568f/menu', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken!);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: userData } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single();

    if (userData?.role !== 'manager') {
      return c.json({ error: 'Manager access required' }, 403);
    }

    const { name, description, price, category } = await c.req.json();

    const { data, error: insertError } = await supabase
      .from('menu_items')
      .insert({ name, description, price, category, available: true })
      .select()
      .single();

    if (insertError) throw insertError;

    return c.json({ success: true, item: data });
  } catch (error) {
    console.error('Add menu item error:', error);
    return c.json({ error: 'Failed to add menu item' }, 500);
  }
});

app.put('/make-server-0c99568f/menu/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken!);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: userData } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single();

    if (userData?.role !== 'manager') {
      return c.json({ error: 'Manager access required' }, 403);
    }

    const itemId = c.req.param('id');
    const updates = await c.req.json();

    const { data, error: updateError } = await supabase
      .from('menu_items')
      .update(updates)
      .eq('id', itemId)
      .select()
      .single();

    if (updateError) throw updateError;

    return c.json({ success: true, item: data });
  } catch (error) {
    console.error('Update menu item error:', error);
    return c.json({ error: 'Failed to update menu item' }, 500);
  }
});

app.delete('/make-server-0c99568f/menu/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken!);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: userData } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single();

    if (userData?.role !== 'manager') {
      return c.json({ error: 'Manager access required' }, 403);
    }

    const itemId = c.req.param('id');

    const { error: deleteError } = await supabase
      .from('menu_items')
      .delete()
      .eq('id', itemId);

    if (deleteError) throw deleteError;

    return c.json({ success: true });
  } catch (error) {
    console.error('Delete menu item error:', error);
    return c.json({ error: 'Failed to delete menu item' }, 500);
  }
});

// Books routes
app.get('/make-server-0c99568f/books', async (c) => {
  try {
    const { data, error } = await supabase
      .from('books')
      .select('*')
      .order('title');

    if (error) {
      console.error('Get books error:', error);
      return c.json({ books: [], error: error.message });
    }

    return c.json({ books: data || [] });
  } catch (error) {
    console.error('Get books error:', error);
    return c.json({ books: [], error: 'Failed to get books' });
  }
});

app.post('/make-server-0c99568f/books', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken!);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: userData } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single();

    if (userData?.role !== 'manager') {
      return c.json({ error: 'Manager access required' }, 403);
    }

    const { title, author, quantity } = await c.req.json();

    const { data, error: insertError } = await supabase
      .from('books')
      .insert({ title, author, quantity, available_quantity: quantity })
      .select()
      .single();

    if (insertError) throw insertError;

    return c.json({ success: true, book: data });
  } catch (error) {
    console.error('Add book error:', error);
    return c.json({ error: 'Failed to add book' }, 500);
  }
});

app.put('/make-server-0c99568f/books/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken!);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: userData } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single();

    if (userData?.role !== 'manager') {
      return c.json({ error: 'Manager access required' }, 403);
    }

    const bookId = c.req.param('id');
    const { quantity } = await c.req.json();

    // Get current book
    const { data: currentBook } = await supabase
      .from('books')
      .select('*')
      .eq('id', bookId)
      .single();

    if (!currentBook) {
      return c.json({ error: 'Book not found' }, 404);
    }

    const diff = quantity - currentBook.quantity;
    const newAvailable = currentBook.available_quantity + diff;

    const { data, error: updateError } = await supabase
      .from('books')
      .update({ 
        quantity, 
        available_quantity: newAvailable 
      })
      .eq('id', bookId)
      .select()
      .single();

    if (updateError) throw updateError;

    return c.json({ success: true, book: data });
  } catch (error) {
    console.error('Update book error:', error);
    return c.json({ error: 'Failed to update book' }, 500);
  }
});

app.delete('/make-server-0c99568f/books/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken!);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: userData } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single();

    if (userData?.role !== 'manager') {
      return c.json({ error: 'Manager access required' }, 403);
    }

    const bookId = c.req.param('id');

    const { error: deleteError } = await supabase
      .from('books')
      .delete()
      .eq('id', bookId);

    if (deleteError) throw deleteError;

    return c.json({ success: true });
  } catch (error) {
    console.error('Delete book error:', error);
    return c.json({ error: 'Failed to delete book' }, 500);
  }
});

// Orders routes
app.post('/make-server-0c99568f/orders', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken!);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { table_id, items, book_id } = await c.req.json();

    // Calculate total
    const menuItemIds = items.map((item: any) => item.menu_item_id);
    const { data: menuItems } = await supabase
      .from('menu_items')
      .select('id, price')
      .in('id', menuItemIds);

    let total = 0;
    const orderItems = items.map((item: any) => {
      const menuItem = menuItems?.find((m: any) => m.id === item.menu_item_id);
      const price = menuItem ? menuItem.price : 0;
      total += price * item.quantity;
      return {
        menu_item_id: item.menu_item_id,
        quantity: item.quantity,
        price
      };
    });

    // Create order
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        customer_id: user.id,
        table_id,
        book_id: book_id || null,
        status: 'pending',
        total_amount: total
      })
      .select()
      .single();

    if (orderError) throw orderError;

    // Insert order items
    const orderItemsData = orderItems.map((item: any) => ({
      order_id: order.id,
      ...item
    }));

    const { error: itemsError } = await supabase
      .from('order_items')
      .insert(orderItemsData);

    if (itemsError) throw itemsError;

    // Update table status
    await supabase
      .from('cafe_tables')
      .update({ status: 'occupied' })
      .eq('id', table_id);

    // Update book availability if renting
    if (book_id) {
      const { data: book } = await supabase
        .from('books')
        .select('available_quantity')
        .eq('id', book_id)
        .single();

      if (book) {
        await supabase
          .from('books')
          .update({ available_quantity: book.available_quantity - 1 })
          .eq('id', book_id);
      }
    }

    return c.json({ success: true, order });
  } catch (error) {
    console.error('Create order error:', error);
    return c.json({ error: 'Failed to create order' }, 500);
  }
});

app.get('/make-server-0c99568f/orders', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ orders: [], error: 'No token provided' });
    }

    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ orders: [], error: 'Unauthorized' });
    }

    const { data: userData } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single();

    let query = supabase
      .from('orders')
      .select(`
        *,
        customer:users!orders_customer_id_fkey(id, name, email),
        staff:users!orders_staff_id_fkey(id, name, email),
        cafe_table:cafe_tables(id, table_number),
        order_items(id, menu_item_id, quantity, price)
      `)
      .order('created_at', { ascending: false });

    // If customer, only show their orders
    if (userData?.role === 'customer') {
      query = query.eq('customer_id', user.id);
    }

    const { data, error: queryError } = await query;

    if (queryError) {
      console.error('Get orders query error:', queryError);
      return c.json({ orders: [], error: queryError.message });
    }

    return c.json({ orders: data || [] });
  } catch (error) {
    console.error('Get orders error:', error);
    return c.json({ orders: [], error: 'Failed to get orders' });
  }
});

app.put('/make-server-0c99568f/orders/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken!);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const orderId = c.req.param('id');
    const { status } = await c.req.json();

    // Get current order
    const { data: currentOrder } = await supabase
      .from('orders')
      .select('staff_id, status')
      .eq('id', orderId)
      .single();

    // If order has been taken by another staff, prevent update
    if (currentOrder?.staff_id && currentOrder.staff_id !== user.id && status === 'taken') {
      return c.json({ error: 'Order already taken by another staff member' }, 409);
    }

    // Update order
    const updateData: any = { status };
    
    // If status is 'taken', assign to current staff member
    if (status === 'taken') {
      updateData.staff_id = user.id;
    }

    const { data, error: updateError } = await supabase
      .from('orders')
      .update(updateData)
      .eq('id', orderId)
      .select(`
        *,
        customer:users!orders_customer_id_fkey(id, name, email),
        staff:users!orders_staff_id_fkey(id, name, email)
      `)
      .single();

    if (updateError) throw updateError;

    return c.json({ success: true, order: data });
  } catch (error) {
    console.error('Update order error:', error);
    return c.json({ error: 'Failed to update order' }, 500);
  }
});

// Payment routes
app.post('/make-server-0c99568f/payments', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken!);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { order_id, amount, payment_method } = await c.req.json();

    // Create payment
    const { data: payment, error: paymentError } = await supabase
      .from('payments')
      .insert({
        order_id,
        customer_id: user.id,
        amount,
        payment_method
      })
      .select()
      .single();

    if (paymentError) throw paymentError;

    // Update order status
    const { data: order } = await supabase
      .from('orders')
      .update({ status: 'completed' })
      .eq('id', order_id)
      .select('table_id, book_id')
      .single();

    if (order) {
      // Free up the table
      await supabase
        .from('cafe_tables')
        .update({ status: 'available' })
        .eq('id', order.table_id);

      // Return book if rented
      if (order.book_id) {
        const { data: book } = await supabase
          .from('books')
          .select('available_quantity')
          .eq('id', order.book_id)
          .single();

        if (book) {
          await supabase
            .from('books')
            .update({ available_quantity: book.available_quantity + 1 })
            .eq('id', order.book_id);
        }
      }
    }

    return c.json({ success: true, payment });
  } catch (error) {
    console.error('Create payment error:', error);
    return c.json({ error: 'Failed to create payment' }, 500);
  }
});

// Analytics route (Manager only)
app.get('/make-server-0c99568f/analytics', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ payments: [], error: 'No token provided' });
    }

    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ payments: [], error: 'Unauthorized' });
    }

    const { data: userData } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single();

    if (userData?.role !== 'manager') {
      return c.json({ payments: [], error: 'Manager access required' });
    }

    const { data, error: queryError } = await supabase
      .from('payments')
      .select(`
        *,
        customer:users!payments_customer_id_fkey(id, name, email),
        order:orders(id, order_items(id, menu_item_id, quantity, price))
      `)
      .order('created_at', { ascending: false });

    if (queryError) {
      console.error('Get analytics query error:', queryError);
      return c.json({ payments: [], error: queryError.message });
    }

    return c.json({ payments: data || [] });
  } catch (error) {
    console.error('Get analytics error:', error);
    return c.json({ payments: [], error: 'Failed to get analytics' });
  }
});

// Staff list route (Manager only)
app.get('/make-server-0c99568f/staff', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ staff: [], error: 'No token provided' });
    }

    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken);
    
    if (error || !user) {
      return c.json({ staff: [], error: 'Unauthorized' });
    }

    const { data: userData } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single();

    if (userData?.role !== 'manager') {
      return c.json({ staff: [], error: 'Manager access required' });
    }

    const { data, error: queryError } = await supabase
      .from('users')
      .select('*')
      .eq('role', 'staff')
      .order('created_at', { ascending: false });

    if (queryError) {
      console.error('Get staff query error:', queryError);
      return c.json({ staff: [], error: queryError.message });
    }

    return c.json({ staff: data || [] });
  } catch (error) {
    console.error('Get staff error:', error);
    return c.json({ staff: [], error: 'Failed to get staff' });
  }
});

// Delete staff route (Manager only)
app.delete('/make-server-0c99568f/staff/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken!);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: userData } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single();

    if (userData?.role !== 'manager') {
      return c.json({ error: 'Manager access required' }, 403);
    }

    const staffId = c.req.param('id');

    // Delete user from auth and public.users (cascade)
    const { error: deleteError } = await supabase.auth.admin.deleteUser(staffId);

    if (deleteError) throw deleteError;

    return c.json({ success: true });
  } catch (error) {
    console.error('Delete staff error:', error);
    return c.json({ error: 'Failed to delete staff' }, 500);
  }
});

// Table waiting list routes
app.post('/make-server-0c99568f/waiting-list', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken!);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: userData } = await supabase
      .from('users')
      .select('name')
      .eq('id', user.id)
      .single();

    const { party_size } = await c.req.json();

    const { data, error: insertError } = await supabase
      .from('table_waiting_list')
      .insert({
        customer_id: user.id,
        customer_name: userData?.name || 'Unknown',
        party_size,
        status: 'waiting'
      })
      .select()
      .single();

    if (insertError) throw insertError;

    return c.json({ success: true, waitingList: data });
  } catch (error) {
    console.error('Add to waiting list error:', error);
    return c.json({ error: 'Failed to add to waiting list' }, 500);
  }
});

app.get('/make-server-0c99568f/waiting-list', async (c) => {
  try {
    const { data, error } = await supabase
      .from('table_waiting_list')
      .select('*')
      .in('status', ['waiting', 'notified'])
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Get waiting list error:', error);
      return c.json({ waitingList: [], error: error.message });
    }

    return c.json({ waitingList: data || [] });
  } catch (error) {
    console.error('Get waiting list error:', error);
    return c.json({ waitingList: [], error: 'Failed to get waiting list' });
  }
});

app.put('/make-server-0c99568f/waiting-list/:id', async (c) => {
  try {
    const waitingListId = c.req.param('id');
    const { status } = await c.req.json();

    const { data, error } = await supabase
      .from('table_waiting_list')
      .update({ status })
      .eq('id', waitingListId)
      .select()
      .single();

    if (error) throw error;

    return c.json({ success: true, waitingList: data });
  } catch (error) {
    console.error('Update waiting list error:', error);
    return c.json({ error: 'Failed to update waiting list' }, 500);
  }
});

// Book request routes
app.post('/make-server-0c99568f/book-requests', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken!);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: userData } = await supabase
      .from('users')
      .select('name')
      .eq('id', user.id)
      .single();

    const { book_id } = await c.req.json();

    const { data, error: insertError } = await supabase
      .from('book_requests')
      .insert({
        customer_id: user.id,
        customer_name: userData?.name || 'Unknown',
        book_id,
        status: 'pending'
      })
      .select(`
        *,
        book:books(id, title, author)
      `)
      .single();

    if (insertError) throw insertError;

    return c.json({ success: true, bookRequest: data });
  } catch (error) {
    console.error('Create book request error:', error);
    return c.json({ error: 'Failed to create book request' }, 500);
  }
});

app.get('/make-server-0c99568f/book-requests', async (c) => {
  try {
    const { data, error } = await supabase
      .from('book_requests')
      .select(`
        *,
        book:books(id, title, author),
        staff:users!book_requests_staff_id_fkey(id, name)
      `)
      .in('status', ['pending', 'approved'])
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Get book requests error:', error);
      return c.json({ bookRequests: [], error: error.message });
    }

    return c.json({ bookRequests: data || [] });
  } catch (error) {
    console.error('Get book requests error:', error);
    return c.json({ bookRequests: [], error: 'Failed to get book requests' });
  }
});

app.put('/make-server-0c99568f/book-requests/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabaseAuth.auth.getUser(accessToken!);
    
    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const bookRequestId = c.req.param('id');
    const { status } = await c.req.json();

    const updateData: any = { status };
    
    // If status is 'approved', assign to current staff member
    if (status === 'approved') {
      updateData.staff_id = user.id;
    }

    const { data, error: updateError } = await supabase
      .from('book_requests')
      .update(updateData)
      .eq('id', bookRequestId)
      .select(`
        *,
        book:books(id, title, author),
        staff:users!book_requests_staff_id_fkey(id, name)
      `)
      .single();

    if (updateError) throw updateError;

    return c.json({ success: true, bookRequest: data });
  } catch (error) {
    console.error('Update book request error:', error);
    return c.json({ error: 'Failed to update book request' }, 500);
  }
});

Deno.serve(app.fetch);
