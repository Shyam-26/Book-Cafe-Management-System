# New Features - Book Cafe Management System

## Overview
This document describes the newly added features for table waiting list and standalone book requests.

## Features Added

### 1. Integrated Table Reservation with Food Ordering
**Customer Dashboard Changes:**
- Combined "Table Selection" and "Food Ordering" into a single unified tab called "Order Food & Reserve Table"
- Customers can now see table availability and select their table while browsing the menu
- Streamlined ordering flow for better user experience

### 2. Table Waiting List
**When Tables Are Full:**
- If all tables are occupied, customers can join a waiting list
- Customers specify their party size (number of people)
- System tracks waiting time automatically
- Real-time updates on table availability

**Customer Features:**
- "Join Waiting List" button appears when no tables are available
- Success notification when added to the waiting list
- Simple form to enter party size

**Staff Features:**
- New "Requests" tab in Staff Dashboard
- View all customers on the waiting list
- See party size and wait time for each customer
- Actions available:
  - **Notify**: Alert customer that a table is becoming available
  - **Seated**: Mark customer as seated and remove from waiting list
- Real-time updates every 5 seconds

### 3. Standalone Book Requests
**Customer Features:**
- Two ways to get a book:
  1. **Add to Order**: Select a book to rent with their food order (existing feature)
  2. **Request Only** (NEW): Request a book separately without ordering food
- "Request Only" button on each book card
- Success notification when book request is submitted
- Can request books even if they're currently unavailable

**Staff Features:**
- View all book requests in the "Requests" tab
- See customer name, book details, and request time
- Actions available:
  - **Approve**: Accept the book request and assign to current staff member
  - **Reject**: Decline the book request
  - **Mark as Served**: Complete the request after delivering the book
- Track which staff member is handling each request

### 4. Staff Requests Management Dashboard
**New Component:** `RequestsManagement.tsx`
- Tabbed interface with two sections:
  - **Table Waiting List**: Manage customers waiting for tables
  - **Book Requests**: Handle standalone book rental requests
- Counter badges showing number of pending requests
- Color-coded status badges:
  - Yellow: Waiting/Pending
  - Blue: Notified
  - Green: Approved
- Relative timestamps (e.g., "5 min ago", "2 hours ago")
- Auto-refresh every 5 seconds for real-time updates

## Database Changes

### New Tables

#### `table_waiting_list`
```sql
- id (UUID, primary key)
- customer_id (UUID, references users)
- customer_name (TEXT)
- party_size (INTEGER)
- status (TEXT: 'waiting', 'notified', 'cancelled', 'seated')
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)
```

#### `book_requests`
```sql
- id (UUID, primary key)
- customer_id (UUID, references users)
- customer_name (TEXT)
- book_id (UUID, references books)
- status (TEXT: 'pending', 'approved', 'rejected', 'served')
- staff_id (UUID, references users - nullable)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)
```

### New API Endpoints

#### Table Waiting List
- `POST /waiting-list` - Add customer to waiting list
- `GET /waiting-list` - Get all active waiting list entries
- `PUT /waiting-list/:id` - Update waiting list status

#### Book Requests
- `POST /book-requests` - Create a new book request
- `GET /book-requests` - Get all active book requests
- `PUT /book-requests/:id` - Update book request status

## Setup Instructions

### 1. Database Migration
Run the updated schema file to create the new tables:
```sql
-- In Supabase SQL Editor, run:
/supabase/migrations/schema.sql
```

The migration includes:
- New table definitions
- RLS policies
- Indexes for performance
- Automatic timestamp triggers

### 2. Edge Function Update
The Edge Function has been updated with new endpoints. No manual changes needed - it will work automatically after deployment.

### 3. Testing the Features

#### Test Table Waiting List:
1. Log in as a customer
2. Go to "Order Food & Reserve Table" tab
3. If tables are available, they'll be shown
4. To test waiting list:
   - Manually set all tables to 'occupied' in database, OR
   - Have multiple customers reserve all tables
5. Click "Join Waiting List" button
6. Enter party size and confirm
7. Log in as staff member
8. Go to "Requests" tab → "Table Waiting List"
9. You'll see the customer waiting
10. Click "Notify" or "Seated" to process

#### Test Book Requests:
1. Log in as a customer
2. Go to "Order Food & Reserve Table" tab
3. Click "Rent a Book" tab
4. Click "Request Only" button on any book
5. Success message will appear
6. Log in as staff member
7. Go to "Requests" tab → "Book Requests"
8. You'll see the book request
9. Click "Approve" to accept
10. Click "Mark as Served" when delivered

## UI/UX Improvements

### Customer Experience
- Unified ordering interface (table + food in one view)
- Clear visual feedback for waiting list status
- Separate book request option for flexibility
- Success notifications for all actions

### Staff Experience
- Centralized request management
- Clear action buttons for each request
- Visual status indicators
- Real-time updates without page refresh
- Request counts in tab labels

## Technical Details

### Real-Time Updates
- Both components poll the server every 5 seconds
- Ensures staff always see the latest requests
- Minimal server load with efficient queries

### Error Handling
- Network error messages
- Database connection status
- User-friendly error displays
- Automatic retry on connection restore

### Status Workflows

#### Waiting List Flow:
1. **waiting** → Customer added to list
2. **notified** → Staff has contacted customer
3. **seated** → Customer assigned to table (final)
4. **cancelled** → Customer left/cancelled (final)

#### Book Request Flow:
1. **pending** → New request submitted
2. **approved** → Staff accepted request (assigns staff_id)
3. **served** → Book delivered to customer (final)
4. **rejected** → Staff declined request (final)

## Future Enhancements

Possible improvements:
- SMS/Email notifications when table becomes available
- Estimated wait time calculation
- Priority queuing for VIP customers
- Book availability notifications
- Customer ratings for books
- Staff performance metrics for request handling

## Notes

- All new features maintain consistency with existing design system
- Colors and styling match the amber/orange theme
- Responsive design for mobile and desktop
- Accessible UI components using shadcn/ui library
