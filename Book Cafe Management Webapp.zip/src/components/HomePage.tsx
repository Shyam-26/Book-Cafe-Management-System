import { useState, useEffect } from 'react';
import { Coffee, Users, BarChart3, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { DatabaseSetupGuide } from './DatabaseSetupGuide';
import { projectId } from '../utils/supabase/info';

interface HomePageProps {
  onRoleSelect: (role: 'customer' | 'staff' | 'manager') => void;
}

export function HomePage({ onRoleSelect }: HomePageProps) {
  const [dbStatus, setDbStatus] = useState<'checking' | 'ready' | 'setup-needed'>('checking');

  useEffect(() => {
    // Check if database is set up by trying to fetch tables
    const checkDatabase = async () => {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/health`
        );
        
        if (!response.ok) {
          setDbStatus('setup-needed');
          return;
        }

        const data = await response.json();
        if (data.status === 'ok' && data.supabaseConfigured) {
          // Try to fetch tables to verify database is set up
          const tablesResponse = await fetch(
            `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/tables`
          );
          
          if (tablesResponse.ok) {
            const tablesData = await tablesResponse.json();
            if (tablesData.error && (tablesData.error.includes('relation') || tablesData.error.includes('does not exist'))) {
              setDbStatus('setup-needed');
            } else {
              setDbStatus('ready');
            }
          } else {
            setDbStatus('ready'); // Server is up, assume database is fine
          }
        } else {
          setDbStatus('setup-needed');
        }
      } catch (error) {
        console.error('Error checking database:', error);
        // If we can't reach the server, show a warning but allow access
        setDbStatus('ready');
      }
    };

    checkDatabase();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-6xl w-full">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Coffee className="w-16 h-16 text-amber-700" />
          </div>
          <h1 className="text-amber-900 mb-2">Book Café Management</h1>
          <p className="text-amber-700">Welcome to your cozy reading and dining space</p>
          
          {dbStatus === 'checking' && (
            <div className="mt-4 text-amber-600 text-sm">
              Checking database status...
            </div>
          )}
        </div>


        <div className="grid md:grid-cols-3 gap-6">
          <Card className="p-8 hover:shadow-xl transition-shadow cursor-pointer bg-white/80 backdrop-blur" onClick={() => onRoleSelect('customer')}>
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Coffee className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-amber-900 mb-3">Customer</h2>
              <p className="text-amber-700 mb-6">Reserve tables, order food, and rent books for your reading session</p>
              <Button className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700">
                Enter as Customer
              </Button>
            </div>
          </Card>

          <Card className="p-8 hover:shadow-xl transition-shadow cursor-pointer bg-white/80 backdrop-blur" onClick={() => onRoleSelect('staff')}>
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-amber-900 mb-3">Staff</h2>
              <p className="text-amber-700 mb-6">Manage table allotments, serve food orders, and handle book rentals</p>
              <Button className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700">
                Enter as Staff
              </Button>
            </div>
          </Card>

          <Card className="p-8 hover:shadow-xl transition-shadow cursor-pointer bg-white/80 backdrop-blur" onClick={() => onRoleSelect('manager')}>
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <BarChart3 className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-amber-900 mb-3">Manager</h2>
              <p className="text-amber-700 mb-6">View analytics, manage inventory, staff, and menu items</p>
              <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700">
                Enter as Manager
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
