import { AlertTriangle } from 'lucide-react';
import { Button } from './ui/button';

export function DatabaseErrorBanner({ onViewGuide }: { onViewGuide: () => void }) {
  return (
    <div className="bg-red-600 text-white px-4 py-3 sticky top-0 z-50 shadow-lg">
      <div className="container mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm">
            <strong>Database Setup Required:</strong> Missing tables detected. Please run the migration script.
          </p>
        </div>
        <Button
          onClick={onViewGuide}
          variant="outline"
          size="sm"
          className="bg-white text-red-600 hover:bg-red-50 border-white flex-shrink-0"
        >
          View Setup Guide
        </Button>
      </div>
    </div>
  );
}
