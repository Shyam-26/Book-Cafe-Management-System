import { Coffee, LogOut } from 'lucide-react';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Analytics } from './Analytics';
import { BookManagement } from './BookManagement';
import { MenuManagement } from './MenuManagement';
import { StaffList } from './StaffList';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
}

interface ManagerDashboardProps {
  user: User;
  accessToken: string;
  onLogout: () => void;
}

export function ManagerDashboard({ user, accessToken, onLogout }: ManagerDashboardProps) {
  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white/90 backdrop-blur rounded-lg shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Coffee className="w-10 h-10 text-purple-700" />
              <div>
                <h1 className="text-purple-900">Welcome, {user.name}!</h1>
                <p className="text-purple-700">Manager Dashboard</p>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={onLogout}
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        <Tabs defaultValue="analytics" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white/90">
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="books">Books</TabsTrigger>
            <TabsTrigger value="menu">Menu</TabsTrigger>
            <TabsTrigger value="staff">Staff</TabsTrigger>
          </TabsList>

          <TabsContent value="analytics">
            <Analytics accessToken={accessToken} />
          </TabsContent>

          <TabsContent value="books">
            <BookManagement accessToken={accessToken} />
          </TabsContent>

          <TabsContent value="menu">
            <MenuManagement accessToken={accessToken} />
          </TabsContent>

          <TabsContent value="staff">
            <StaffList accessToken={accessToken} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
