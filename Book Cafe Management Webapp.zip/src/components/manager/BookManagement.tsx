import { useState, useEffect } from 'react';
import { Plus, Minus, Trash2, Book } from 'lucide-react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface BookItem {
  id: string;
  title: string;
  author: string;
  quantity: number;
  available_quantity: number;
}

interface BookManagementProps {
  accessToken: string;
}

export function BookManagement({ accessToken }: BookManagementProps) {
  const [books, setBooks] = useState<BookItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newBook, setNewBook] = useState({
    title: '',
    author: '',
    quantity: 1
  });

  const fetchBooks = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/books`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      const data = await response.json();
      setBooks(data.books || []);
    } catch (error) {
      console.error('Error fetching books:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  const handleAddBook = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/books`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify(newBook),
        }
      );

      if (response.ok) {
        setDialogOpen(false);
        setNewBook({ title: '', author: '', quantity: 1 });
        fetchBooks();
      }
    } catch (error) {
      console.error('Error adding book:', error);
    }
  };

  const handleUpdateQuantity = async (bookId: string, newQuantity: number) => {
    if (newQuantity < 0) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/books/${bookId}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({ quantity: newQuantity }),
        }
      );

      if (response.ok) {
        fetchBooks();
      }
    } catch (error) {
      console.error('Error updating book:', error);
    }
  };

  const handleDeleteBook = async (bookId: string) => {
    if (!confirm('Are you sure you want to delete this book?')) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/books/${bookId}`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
          },
        }
      );

      if (response.ok) {
        fetchBooks();
      }
    } catch (error) {
      console.error('Error deleting book:', error);
    }
  };

  if (loading) {
    return (
      <Card className="p-8 text-center bg-white/90">
        <p className="text-purple-700">Loading books...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-white/90">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-purple-900">Book Inventory Management</h2>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-purple-500 to-pink-600">
                <Plus className="w-4 h-4 mr-2" />
                Add New Book
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Book</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddBook} className="space-y-4">
                <div>
                  <Label htmlFor="title">Book Title</Label>
                  <Input
                    id="title"
                    value={newBook.title}
                    onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
                    required
                    placeholder="Enter book title"
                  />
                </div>

                <div>
                  <Label htmlFor="author">Author</Label>
                  <Input
                    id="author"
                    value={newBook.author}
                    onChange={(e) => setNewBook({ ...newBook, author: e.target.value })}
                    required
                    placeholder="Enter author name"
                  />
                </div>

                <div>
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    type="number"
                    min="1"
                    value={newBook.quantity}
                    onChange={(e) => setNewBook({ ...newBook, quantity: parseInt(e.target.value) })}
                    required
                  />
                </div>

                <Button type="submit" className="w-full">
                  Add Book
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {books.map((book) => (
            <Card key={book.id} className="p-6">
              <div className="flex gap-4">
                <div className="w-12 h-16 bg-purple-200 rounded flex items-center justify-center flex-shrink-0">
                  <Book className="w-6 h-6 text-purple-700" />
                </div>
                <div className="flex-1">
                  <h3 className="text-purple-900 mb-1">{book.title}</h3>
                  <p className="text-purple-700 mb-3">by {book.author}</p>

                  <div className="flex items-center gap-3 mb-3">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpdateQuantity(book.id, book.quantity - 1)}
                      disabled={book.quantity <= 0}
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <div className="text-center min-w-24">
                      <p className="text-purple-900">{book.quantity}</p>
                      <p className="text-purple-700">total</p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpdateQuantity(book.id, book.quantity + 1)}
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <p className="text-purple-700">
                      Available: {book.available_quantity}
                    </p>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDeleteBook(book.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {books.length === 0 && (
          <div className="text-center py-12">
            <Book className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">No books in inventory. Add your first book!</p>
          </div>
        )}
      </Card>
    </div>
  );
}
