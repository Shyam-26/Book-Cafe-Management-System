import { useState, useEffect } from 'react';
import { Users, Mail, Plus, Trash2 } from 'lucide-react';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface StaffMember {
  id: string;
  email: string;
  name: string;
  role: string;
  created_at: string;
}

interface StaffListProps {
  accessToken: string;
}

export function StaffList({ accessToken }: StaffListProps) {
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newStaff, setNewStaff] = useState({
    name: '',
    email: '',
    password: ''
  });

  const fetchStaff = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/staff`,
        {
          headers: {
            'Authorization': `Bearer ${accessToken}`,
          },
        }
      );

      const data = await response.json();
      setStaff(data.staff || []);
    } catch (error) {
      console.error('Error fetching staff:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStaff();
  }, []);

  const handleAddStaff = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/signup`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            ...newStaff,
            role: 'staff'
          }),
        }
      );

      if (response.ok) {
        setDialogOpen(false);
        setNewStaff({ name: '', email: '', password: '' });
        fetchStaff();
      } else {
        const data = await response.json();
        alert(data.error || 'Failed to add staff');
      }
    } catch (error) {
      console.error('Error adding staff:', error);
      alert('Failed to add staff');
    }
  };

  const handleDeleteStaff = async (staffId: string, staffName: string) => {
    if (!confirm(`Are you sure you want to remove ${staffName} from staff?`)) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/staff/${staffId}`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
          },
        }
      );

      if (response.ok) {
        fetchStaff();
      } else {
        const data = await response.json();
        alert(data.error || 'Failed to remove staff');
      }
    } catch (error) {
      console.error('Error deleting staff:', error);
      alert('Failed to remove staff');
    }
  };

  if (loading) {
    return (
      <Card className="p-8 text-center bg-white/90">
        <p className="text-purple-700">Loading staff list...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-white/90">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <h2 className="text-purple-900">Staff Members</h2>
            <Badge className="bg-purple-100 text-purple-800">
              {staff.length} Total
            </Badge>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-purple-500 to-pink-600">
                <Plus className="w-4 h-4 mr-2" />
                Add Staff
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Staff Member</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddStaff} className="space-y-4">
                <div>
                  <Label htmlFor="staff-name">Full Name</Label>
                  <Input
                    id="staff-name"
                    value={newStaff.name}
                    onChange={(e) => setNewStaff({ ...newStaff, name: e.target.value })}
                    required
                    placeholder="Enter staff name"
                  />
                </div>

                <div>
                  <Label htmlFor="staff-email">Email</Label>
                  <Input
                    id="staff-email"
                    type="email"
                    value={newStaff.email}
                    onChange={(e) => setNewStaff({ ...newStaff, email: e.target.value })}
                    required
                    placeholder="Enter email address"
                  />
                </div>

                <div>
                  <Label htmlFor="staff-password">Password</Label>
                  <Input
                    id="staff-password"
                    type="password"
                    value={newStaff.password}
                    onChange={(e) => setNewStaff({ ...newStaff, password: e.target.value })}
                    required
                    placeholder="Enter password"
                    minLength={6}
                  />
                </div>

                <Button type="submit" className="w-full">
                  Add Staff Member
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {staff.length === 0 ? (
          <div className="text-center py-12">
            <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">No staff members registered yet</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {staff.map((member) => (
              <Card key={member.id} className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Users className="w-6 h-6 text-purple-700" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-purple-900 mb-1">{member.name}</h3>
                    <div className="flex items-center gap-2 text-purple-700 mb-2">
                      <Mail className="w-4 h-4" />
                      <span>{member.email}</span>
                    </div>
                    <p className="text-purple-700 mb-3">
                      Joined: {new Date(member.created_at).toLocaleDateString()}
                    </p>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDeleteStaff(member.id, member.name)}
                    >
                      <Trash2 className="w-4 h-4 mr-1" />
                      Remove Staff
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
