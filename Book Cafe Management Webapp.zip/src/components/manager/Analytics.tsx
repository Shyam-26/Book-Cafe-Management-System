import { useState, useEffect } from 'react';
import { DollarSign, TrendingUp, Users, ShoppingCart } from 'lucide-react';
import { Card } from '../ui/card';
import { projectId } from '../../utils/supabase/info';

interface Payment {
  id: string;
  order_id: string;
  customer_id: string;
  amount: number;
  payment_method: string;
  created_at: string;
  customer?: {
    name: string;
    email: string;
  };
  order?: {
    items: any[];
  };
}

interface AnalyticsProps {
  accessToken: string;
}

export function Analytics({ accessToken }: AnalyticsProps) {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAnalytics = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/analytics`,
        {
          headers: {
            'Authorization': `Bearer ${accessToken}`,
          },
        }
      );

      const data = await response.json();
      setPayments(data.payments || []);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
    const interval = setInterval(fetchAnalytics, 10000);
    return () => clearInterval(interval);
  }, []);

  const totalRevenue = payments.reduce((sum, p) => sum + p.amount, 0);
  const totalOrders = payments.length;
  const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
  const uniqueCustomers = new Set(payments.map(p => p.customer_id)).size;

  const paymentsByMethod = payments.reduce((acc, p) => {
    acc[p.payment_method] = (acc[p.payment_method] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  if (loading) {
    return (
      <Card className="p-8 text-center bg-white/90">
        <p className="text-purple-700">Loading analytics...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-4 gap-6">
        <Card className="p-6 bg-gradient-to-br from-green-50 to-emerald-100">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="w-8 h-8 text-green-600" />
          </div>
          <p className="text-green-700 mb-1">Total Revenue</p>
          <p className="text-green-900">${totalRevenue.toFixed(2)}</p>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-blue-50 to-indigo-100">
          <div className="flex items-center justify-between mb-2">
            <ShoppingCart className="w-8 h-8 text-blue-600" />
          </div>
          <p className="text-blue-700 mb-1">Total Orders</p>
          <p className="text-blue-900">{totalOrders}</p>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-purple-50 to-pink-100">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="w-8 h-8 text-purple-600" />
          </div>
          <p className="text-purple-700 mb-1">Avg Order Value</p>
          <p className="text-purple-900">${averageOrderValue.toFixed(2)}</p>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-orange-50 to-amber-100">
          <div className="flex items-center justify-between mb-2">
            <Users className="w-8 h-8 text-orange-600" />
          </div>
          <p className="text-orange-700 mb-1">Unique Customers</p>
          <p className="text-orange-900">{uniqueCustomers}</p>
        </Card>
      </div>

      <Card className="p-6 bg-white/90">
        <h2 className="text-purple-900 mb-4">Payment Methods</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {Object.entries(paymentsByMethod).map(([method, count]) => (
            <Card key={method} className="p-4 bg-purple-50">
              <p className="text-purple-900 capitalize">{method}</p>
              <p className="text-purple-700">{count} transaction(s)</p>
            </Card>
          ))}
        </div>
      </Card>

      <Card className="p-6 bg-white/90">
        <h2 className="text-purple-900 mb-4">Payment History</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-purple-200">
                <th className="text-left p-3 text-purple-900">Date</th>
                <th className="text-left p-3 text-purple-900">Customer</th>
                <th className="text-left p-3 text-purple-900">Email</th>
                <th className="text-left p-3 text-purple-900">Method</th>
                <th className="text-right p-3 text-purple-900">Amount</th>
              </tr>
            </thead>
            <tbody>
              {payments.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()).map((payment) => (
                <tr key={payment.id} className="border-b border-purple-100 hover:bg-purple-50">
                  <td className="p-3 text-purple-700">
                    {new Date(payment.created_at).toLocaleString()}
                  </td>
                  <td className="p-3 text-purple-900">
                    {payment.customer?.name || 'Unknown'}
                  </td>
                  <td className="p-3 text-purple-700">
                    {payment.customer?.email || 'N/A'}
                  </td>
                  <td className="p-3 text-purple-700 capitalize">
                    {payment.payment_method}
                  </td>
                  <td className="p-3 text-right text-purple-900">
                    ${payment.amount.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {payments.length === 0 && (
            <div className="text-center py-12">
              <p className="text-purple-700">No payment records yet</p>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
