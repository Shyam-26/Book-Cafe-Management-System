import { useState, useEffect } from 'react';
import { Clock, Book, CheckCircle, X, Users } from 'lucide-react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface WaitingListItem {
  id: string;
  customer_name: string;
  party_size: number;
  status: string;
  created_at: string;
}

interface BookRequest {
  id: string;
  customer_name: string;
  status: string;
  created_at: string;
  book: {
    id: string;
    title: string;
    author: string;
  };
  staff?: {
    id: string;
    name: string;
  };
}

interface RequestsManagementProps {
  accessToken: string;
  staffName: string;
}

export function RequestsManagement({ accessToken, staffName }: RequestsManagementProps) {
  const [waitingList, setWaitingList] = useState<WaitingListItem[]>([]);
  const [bookRequests, setBookRequests] = useState<BookRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      const [waitingResponse, bookRequestsResponse] = await Promise.all([
        fetch(`https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/waiting-list`, {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` },
        }),
        fetch(`https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/book-requests`, {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` },
        })
      ]);

      if (!waitingResponse.ok || !bookRequestsResponse.ok) {
        setError('Unable to load requests. Please try again.');
        setLoading(false);
        return;
      }

      const waitingData = await waitingResponse.json();
      const bookRequestsData = await bookRequestsResponse.json();

      if (waitingData.error || bookRequestsData.error) {
        setError(waitingData.error || bookRequestsData.error);
      } else {
        setError(null);
      }

      setWaitingList(waitingData.waitingList || []);
      setBookRequests(bookRequestsData.bookRequests || []);
    } catch (error) {
      console.error('Error fetching requests:', error);
      setError('Failed to load requests. Please check your connection.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    // Refresh every 5 seconds
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleWaitingListUpdate = async (id: string, status: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/waiting-list/${id}`,
        {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ status }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to update waiting list');
      }

      fetchData();
    } catch (error) {
      console.error('Error updating waiting list:', error);
      setError('Failed to update waiting list. Please try again.');
    }
  };

  const handleBookRequestUpdate = async (id: string, status: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/book-requests/${id}`,
        {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ status }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to update book request');
      }

      fetchData();
    } catch (error) {
      console.error('Error updating book request:', error);
      setError('Failed to update book request. Please try again.');
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'waiting':
        return <Badge className="bg-yellow-100 text-yellow-800">Waiting</Badge>;
      case 'notified':
        return <Badge className="bg-blue-100 text-blue-800">Notified</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>;
      case 'approved':
        return <Badge className="bg-green-100 text-green-800">Approved</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} min ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    return date.toLocaleDateString();
  };

  if (loading) {
    return (
      <Card className="p-8 text-center bg-white/90">
        <p className="text-blue-700">Loading requests...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {error && (
        <Card className="p-4 bg-yellow-50 border-yellow-200">
          <div className="flex items-start gap-3">
            <div className="text-yellow-600">⚠️</div>
            <div className="flex-1">
              <p className="text-yellow-800">{error}</p>
            </div>
          </div>
        </Card>
      )}

      <Tabs defaultValue="waiting" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 bg-white/90">
          <TabsTrigger value="waiting">
            Table Waiting List ({waitingList.length})
          </TabsTrigger>
          <TabsTrigger value="books">
            Book Requests ({bookRequests.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="waiting">
          <Card className="p-6 bg-white/90">
            <div className="flex items-center gap-3 mb-6">
              <Clock className="w-6 h-6 text-blue-700" />
              <h2 className="text-blue-900">Table Waiting List</h2>
            </div>

            {waitingList.length === 0 ? (
              <div className="text-center py-8 text-blue-700">
                No customers waiting for tables
              </div>
            ) : (
              <div className="space-y-3">
                {waitingList.map((item) => (
                  <Card key={item.id} className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-blue-900">{item.customer_name}</h3>
                          {getStatusBadge(item.status)}
                        </div>
                        <div className="flex items-center gap-4 text-blue-700">
                          <div className="flex items-center gap-1">
                            <Users className="w-4 h-4" />
                            <span>Party of {item.party_size}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            <span>{formatTime(item.created_at)}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {item.status === 'waiting' && (
                          <>
                            <Button
                              size="sm"
                              onClick={() => handleWaitingListUpdate(item.id, 'notified')}
                              className="bg-blue-600 hover:bg-blue-700"
                            >
                              Notify
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleWaitingListUpdate(item.id, 'seated')}
                            >
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Seated
                            </Button>
                          </>
                        )}
                        {item.status === 'notified' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleWaitingListUpdate(item.id, 'seated')}
                          >
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Seated
                          </Button>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </Card>
        </TabsContent>

        <TabsContent value="books">
          <Card className="p-6 bg-white/90">
            <div className="flex items-center gap-3 mb-6">
              <Book className="w-6 h-6 text-blue-700" />
              <h2 className="text-blue-900">Book Requests</h2>
            </div>

            {bookRequests.length === 0 ? (
              <div className="text-center py-8 text-blue-700">
                No book requests
              </div>
            ) : (
              <div className="space-y-3">
                {bookRequests.map((request) => (
                  <Card key={request.id} className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-blue-900">{request.customer_name}</h3>
                          {getStatusBadge(request.status)}
                        </div>
                        <div className="text-blue-700 mb-2">
                          <p><strong>Book:</strong> {request.book.title}</p>
                          <p><strong>Author:</strong> {request.book.author}</p>
                        </div>
                        <div className="flex items-center gap-4 text-blue-700">
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            <span>{formatTime(request.created_at)}</span>
                          </div>
                          {request.staff && (
                            <span>Handled by: {request.staff.name}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {request.status === 'pending' && (
                          <>
                            <Button
                              size="sm"
                              onClick={() => handleBookRequestUpdate(request.id, 'approved')}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleBookRequestUpdate(request.id, 'rejected')}
                            >
                              <X className="w-4 h-4 mr-1" />
                              Reject
                            </Button>
                          </>
                        )}
                        {request.status === 'approved' && (
                          <Button
                            size="sm"
                            onClick={() => handleBookRequestUpdate(request.id, 'served')}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            Mark as Served
                          </Button>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
