import { useState, useEffect } from 'react';
import { Book, CheckCircle } from 'lucide-react';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface Order {
  id: string;
  customer_id: string;
  book_id: string | null;
  staff_id: string | null;
  status: string;
  created_at: string;
  customer?: {
    name: string;
  };
  staff?: {
    name: string;
  };
}

interface BookItem {
  id: string;
  title: string;
  author: string;
  quantity: number;
  available_quantity: number;
}

interface BookServingProps {
  accessToken: string;
  staffName: string;
}

export function BookServing({ accessToken, staffName }: BookServingProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [books, setBooks] = useState<BookItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      const [ordersResponse, booksResponse] = await Promise.all([
        fetch(`https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/orders`, {
          headers: { 'Authorization': `Bearer ${accessToken}` },
        }),
        fetch(`https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/books`, {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` },
        })
      ]);

      if (!ordersResponse.ok || !booksResponse.ok) {
        setError('Unable to load book rentals. Please refresh the page.');
        setLoading(false);
        return;
      }

      const ordersData = await ordersResponse.json();
      const booksData = await booksResponse.json();

      if (ordersData.error || booksData.error) {
        setError(ordersData.error || booksData.error);
      } else {
        setError(null);
      }

      setOrders(ordersData.orders || []);
      setBooks(booksData.books || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Failed to load book rentals. Please check your connection.');
      setOrders([]);
      setBooks([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  const getBookTitle = (bookId: string) => {
    const book = books.find(b => b.id === bookId);
    return book ? book.title : 'Unknown Book';
  };

  const ordersWithBooks = orders.filter(o => o.book_id && o.status !== 'completed');

  if (loading) {
    return (
      <Card className="p-8 text-center bg-white/90">
        <p className="text-blue-700">Loading book rentals...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <Card className="p-4 bg-yellow-50 border-yellow-200">
          <div className="flex items-start gap-3">
            <div className="text-yellow-600">⚠️</div>
            <div className="flex-1">
              <p className="text-yellow-800">{error}</p>
              {ordersWithBooks.length === 0 && (
                <p className="text-yellow-700 text-sm mt-1">
                  Book rentals will appear here once customers rent books.
                </p>
              )}
            </div>
          </div>
        </Card>
      )}

      <Card className="p-6 bg-white/90">
        <h2 className="text-blue-900 mb-6">Book Rental Management</h2>

        <div className="mb-8">
          <h3 className="text-blue-900 mb-4">Current Book Inventory</h3>
          <div className="grid md:grid-cols-2 gap-4">
            {books.map((book) => (
              <Card key={book.id} className="p-4">
                <div className="flex gap-4">
                  <div className="w-12 h-16 bg-blue-200 rounded flex items-center justify-center flex-shrink-0">
                    <Book className="w-6 h-6 text-blue-700" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-blue-900 mb-1">{book.title}</h4>
                    <p className="text-blue-700 mb-2">by {book.author}</p>
                    <div className="flex gap-2">
                      <Badge className="bg-blue-100 text-blue-800">
                        Total: {book.quantity}
                      </Badge>
                      <Badge
                        className={
                          book.available_quantity > 0
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }
                      >
                        Available: {book.available_quantity}
                      </Badge>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-blue-900 mb-4">Active Book Rentals</h3>
          {ordersWithBooks.length === 0 ? (
            <div className="text-center py-12">
              <Book className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No active book rentals at the moment</p>
            </div>
          ) : (
            <div className="space-y-4">
              {ordersWithBooks.map((order) => (
                <Card key={order.id} className="p-6 bg-gradient-to-r from-white to-blue-50">
                  <div className="flex justify-between items-start">
                    <div className="flex gap-4 flex-1">
                      <div className="w-12 h-16 bg-blue-200 rounded flex items-center justify-center flex-shrink-0">
                        <Book className="w-6 h-6 text-blue-700" />
                      </div>
                      <div>
                        <h4 className="text-blue-900 mb-1">
                          {getBookTitle(order.book_id!)}
                        </h4>
                        <p className="text-blue-700">
                          Customer: {order.customer?.name || 'Unknown'}
                        </p>
                        {order.staff && (
                          <p className="text-blue-700">
                            Handled by: {order.staff.name}
                          </p>
                        )}
                        <p className="text-blue-700">
                          Rented: {new Date(order.created_at).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <Badge
                      className={
                        order.status === 'served'
                          ? 'bg-purple-100 text-purple-800'
                          : order.status === 'preparing'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }
                    >
                      {order.status === 'served' ? 'In Use' : order.status}
                    </Badge>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>

        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-blue-800">
            <strong>Note:</strong> Books are automatically returned when customers complete their payment.
          </p>
        </div>
      </Card>
    </div>
  );
}
