import { useState, useEffect } from 'react';
import { Users } from 'lucide-react';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface Table {
  id: string;
  table_number: number;
  capacity: number;
  status: 'available' | 'reserved' | 'occupied';
}

interface TableAllotmentProps {
  accessToken: string;
}

export function TableAllotment({ accessToken }: TableAllotmentProps) {
  const [tables, setTables] = useState<Table[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchTables = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/tables`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      const data = await response.json();
      setTables(data.tables || []);
    } catch (error) {
      console.error('Error fetching tables:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTables();
    const interval = setInterval(fetchTables, 5000);
    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'reserved':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'occupied':
        return 'bg-red-100 text-red-800 border-red-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const statusCounts = {
    available: tables.filter(t => t.status === 'available').length,
    reserved: tables.filter(t => t.status === 'reserved').length,
    occupied: tables.filter(t => t.status === 'occupied').length,
  };

  if (loading) {
    return (
      <Card className="p-8 text-center bg-white/90">
        <p className="text-blue-700">Loading tables...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-white/90">
        <h2 className="text-blue-900 mb-4">Table Status Overview</h2>
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg text-center">
            <p className="text-green-900 mb-1">{statusCounts.available}</p>
            <p className="text-green-700">Available</p>
          </div>
          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg text-center">
            <p className="text-yellow-900 mb-1">{statusCounts.reserved}</p>
            <p className="text-yellow-700">Reserved</p>
          </div>
          <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-center">
            <p className="text-red-900 mb-1">{statusCounts.occupied}</p>
            <p className="text-red-700">Occupied</p>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          {tables.map((table) => (
            <Card key={table.id} className="p-6">
              <div className="text-center">
                <div className="flex items-center justify-center mb-3">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
                    table.status === 'available' ? 'bg-green-100' :
                    table.status === 'reserved' ? 'bg-yellow-100' :
                    'bg-red-100'
                  }`}>
                    <span className={`${
                      table.status === 'available' ? 'text-green-900' :
                      table.status === 'reserved' ? 'text-yellow-900' :
                      'text-red-900'
                    }`}>
                      {table.table_number}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-2 mb-3">
                  <Users className="w-4 h-4 text-blue-700" />
                  <span className="text-blue-900">Capacity: {table.capacity}</span>
                </div>

                <Badge className={getStatusColor(table.status)}>
                  {table.status}
                </Badge>
              </div>
            </Card>
          ))}
        </div>
      </Card>
    </div>
  );
}
