import { useState, useEffect } from 'react';
import { Clock, CheckCircle, ChefHat } from 'lucide-react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface Order {
  id: string;
  customer_id: string;
  table_id: string;
  staff_id: string | null;
  order_items: Array<{
    menu_item_id: string;
    quantity: number;
    price: number;
  }>;
  status: string;
  total_amount: number;
  created_at: string;
  customer?: {
    name: string;
    email: string;
  };
  staff?: {
    name: string;
    email: string;
  };
  cafe_table?: {
    table_number: number;
  };
}

interface FoodServingProps {
  accessToken: string;
  staffName: string;
}

export function FoodServing({ accessToken, staffName }: FoodServingProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [menu, setMenu] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      const [ordersResponse, menuResponse] = await Promise.all([
        fetch(`https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/orders`, {
          headers: { 'Authorization': `Bearer ${accessToken}` },
        }),
        fetch(`https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/menu`, {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` },
        })
      ]);

      if (!ordersResponse.ok || !menuResponse.ok) {
        setError('Unable to load orders. Please refresh the page.');
        setLoading(false);
        return;
      }

      const ordersData = await ordersResponse.json();
      const menuData = await menuResponse.json();

      if (ordersData.error || menuData.error) {
        setError(ordersData.error || menuData.error);
      } else {
        setError(null);
      }

      setOrders(ordersData.orders || []);
      setMenu(menuData.menu || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Failed to load orders. Please check your connection.');
      setOrders([]);
      setMenu([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleStatusUpdate = async (orderId: string, newStatus: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/orders/${orderId}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({ status: newStatus }),
        }
      );

      if (response.ok) {
        fetchData();
      }
    } catch (error) {
      console.error('Error updating order:', error);
    }
  };

  const getMenuItemName = (menuItemId: string) => {
    const item = menu.find(m => m.id === menuItemId);
    return item ? item.name : 'Unknown Item';
  };

  const activeOrders = orders.filter(o => o.status !== 'completed');
  const pendingOrders = activeOrders.filter(o => o.status === 'pending');
  const takenOrders = activeOrders.filter(o => o.status === 'taken');
  const preparingOrders = activeOrders.filter(o => o.status === 'preparing');
  const servedOrders = activeOrders.filter(o => o.status === 'served');

  if (loading) {
    return (
      <Card className="p-8 text-center bg-white/90">
        <p className="text-blue-700">Loading orders...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <Card className="p-4 bg-yellow-50 border-yellow-200">
          <div className="flex items-start gap-3">
            <div className="text-yellow-600">⚠️</div>
            <div className="flex-1">
              <p className="text-yellow-800">{error}</p>
              {orders.length === 0 && (
                <p className="text-yellow-700 text-sm mt-1">
                  Orders will appear here once the database is set up.
                </p>
              )}
            </div>
          </div>
        </Card>
      )}

      <Card className="p-6 bg-white/90">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-blue-900">Food Service Queue</h2>
          <div className="flex gap-3">
            <Badge className="bg-yellow-100 text-yellow-800">
              {pendingOrders.length} Pending
            </Badge>
            <Badge className="bg-orange-100 text-orange-800">
              {takenOrders.length} Taken
            </Badge>
            <Badge className="bg-blue-100 text-blue-800">
              {preparingOrders.length} Preparing
            </Badge>
            <Badge className="bg-purple-100 text-purple-800">
              {servedOrders.length} Served
            </Badge>
          </div>
        </div>

        {activeOrders.length === 0 ? (
          <div className="text-center py-12">
            <ChefHat className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">No active orders at the moment</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activeOrders.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()).map((order) => (
              <Card key={order.id} className="p-6 bg-gradient-to-r from-white to-blue-50">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <Clock className="w-5 h-5 text-blue-600" />
                      <h3 className="text-blue-900">Order #{order.id.slice(-8)}</h3>
                    </div>
                    <p className="text-blue-700">
                      Customer: {order.customer?.name || 'Unknown'}
                    </p>
                    <p className="text-blue-700">
                      Table: {order.cafe_table?.table_number || 'N/A'}
                    </p>
                    {order.staff && (
                      <p className="text-blue-700">
                        Assigned to: {order.staff.name}
                      </p>
                    )}
                    <p className="text-blue-700">
                      {new Date(order.created_at).toLocaleString()}
                    </p>
                  </div>
                  <Badge
                    className={
                      order.status === 'pending'
                        ? 'bg-yellow-100 text-yellow-800'
                        : order.status === 'taken'
                        ? 'bg-orange-100 text-orange-800'
                        : order.status === 'preparing'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-purple-100 text-purple-800'
                    }
                  >
                    {order.status}
                  </Badge>
                </div>

                <div className="mb-4">
                  <p className="text-blue-900 mb-2">Items:</p>
                  <div className="space-y-1">
                    {order.order_items?.map((item, idx) => (
                      <div key={idx} className="flex justify-between text-blue-700 bg-white/50 p-2 rounded">
                        <span>
                          {getMenuItemName(item.menu_item_id)} × {item.quantity}
                        </span>
                        <span>${(item.price * item.quantity).toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3">
                  {order.status === 'pending' && (
                    <Button
                      onClick={() => handleStatusUpdate(order.id, 'taken')}
                      className="flex-1 bg-orange-600 hover:bg-orange-700"
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Take Order
                    </Button>
                  )}

                  {order.status === 'taken' && (
                    <Button
                      onClick={() => handleStatusUpdate(order.id, 'preparing')}
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                    >
                      <ChefHat className="w-4 h-4 mr-2" />
                      Start Preparing
                    </Button>
                  )}

                  {order.status === 'preparing' && (
                    <Button
                      onClick={() => handleStatusUpdate(order.id, 'served')}
                      className="flex-1 bg-purple-600 hover:bg-purple-700"
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Mark as Served
                    </Button>
                  )}

                  {order.status === 'served' && (
                    <div className="flex-1 p-3 bg-purple-100 border border-purple-300 rounded text-center">
                      <p className="text-purple-800">
                        Waiting for customer to complete payment
                      </p>
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
