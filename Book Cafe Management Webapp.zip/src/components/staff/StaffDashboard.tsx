import { Coffee, LogOut } from 'lucide-react';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { TableAllotment } from './TableAllotment';
import { FoodServing } from './FoodServing';
import { BookServing } from './BookServing';
import { RequestsManagement } from './RequestsManagement';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
}

interface StaffDashboardProps {
  user: User;
  accessToken: string;
  onLogout: () => void;
}

export function StaffDashboard({ user, accessToken, onLogout }: StaffDashboardProps) {
  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white/90 backdrop-blur rounded-lg shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Coffee className="w-10 h-10 text-blue-700" />
              <div>
                <h1 className="text-blue-900">Welcome, {user.name}!</h1>
                <p className="text-blue-700">Staff Dashboard</p>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={onLogout}
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        <Tabs defaultValue="food" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white/90">
            <TabsTrigger value="food">Food Serving</TabsTrigger>
            <TabsTrigger value="table">Table Allotment</TabsTrigger>
            <TabsTrigger value="book">Book Serving</TabsTrigger>
            <TabsTrigger value="requests">Requests</TabsTrigger>
          </TabsList>

          <TabsContent value="food">
            <FoodServing accessToken={accessToken} staffName={user.name} />
          </TabsContent>

          <TabsContent value="table">
            <TableAllotment accessToken={accessToken} />
          </TabsContent>

          <TabsContent value="book">
            <BookServing accessToken={accessToken} staffName={user.name} />
          </TabsContent>

          <TabsContent value="requests">
            <RequestsManagement accessToken={accessToken} staffName={user.name} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
