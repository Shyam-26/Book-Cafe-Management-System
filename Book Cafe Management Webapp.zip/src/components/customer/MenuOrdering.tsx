import { useState, useEffect } from 'react';
import { Plus, Minus, ShoppingCart, Book, CheckCircle } from 'lucide-react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { projectId, publicAnonKey } from '../../utils/supabase/info';
import type { CartItem } from './CustomerDashboard';

interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  available: boolean;
}

interface BookItem {
  id: string;
  title: string;
  author: string;
  quantity: number;
  available_quantity: number;
}

interface MenuOrderingProps {
  accessToken: string;
  cart: CartItem[];
  selectedBook: string | null;
  onAddToCart: (item: CartItem) => void;
  onRemoveFromCart: (menuItemId: string) => void;
  onUpdateQuantity: (menuItemId: string, quantity: number) => void;
  onSelectBook: (bookId: string | null) => void;
}

export function MenuOrdering({
  accessToken,
  cart,
  selectedBook,
  onAddToCart,
  onRemoveFromCart,
  onUpdateQuantity,
  onSelectBook
}: MenuOrderingProps) {
  const [menu, setMenu] = useState<MenuItem[]>([]);
  const [books, setBooks] = useState<BookItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [bookRequestSuccess, setBookRequestSuccess] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [menuResponse, booksResponse] = await Promise.all([
        fetch(`https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/menu`, {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` },
        }),
        fetch(`https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/books`, {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` },
        })
      ]);

      if (!menuResponse.ok || !booksResponse.ok) {
        setError('Unable to load menu and books. Please try again.');
        setLoading(false);
        return;
      }

      const menuData = await menuResponse.json();
      const booksData = await booksResponse.json();

      if (menuData.error || booksData.error) {
        setError(menuData.error || booksData.error);
      } else {
        setError(null);
      }

      setMenu(menuData.menu || []);
      setBooks(booksData.books || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Failed to load menu and books. Please check your connection.');
    } finally {
      setLoading(false);
    }
  };

  const categories = [...new Set(menu.map(item => item.category))];

  const handleBookRequest = async (bookId: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/book-requests`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ book_id: bookId }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to request book');
      }

      setBookRequestSuccess(true);
      setTimeout(() => setBookRequestSuccess(false), 5000);
    } catch (error) {
      console.error('Error requesting book:', error);
      setError('Failed to request book. Please try again.');
    }
  };

  const getCartQuantity = (menuItemId: string) => {
    return cart.find(item => item.menu_item_id === menuItemId)?.quantity || 0;
  };

  if (loading) {
    return (
      <Card className="p-8 text-center bg-white/90">
        <p className="text-amber-700">Loading menu...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {bookRequestSuccess && (
        <Card className="p-4 bg-green-50 border-green-300">
          <div className="flex items-center gap-3 text-green-800">
            <CheckCircle className="w-5 h-5" />
            <p>Book request sent successfully! Staff will process your request shortly.</p>
          </div>
        </Card>
      )}

      {error && (
        <Card className="p-4 bg-yellow-50 border-yellow-200">
          <div className="flex items-start gap-3">
            <div className="text-yellow-600">⚠️</div>
            <div className="flex-1">
              <p className="text-yellow-800">{error}</p>
              {menu.length === 0 && books.length === 0 && (
                <p className="text-yellow-700 text-sm mt-1">
                  The menu and books will appear here once the database is set up.
                </p>
              )}
            </div>
          </div>
        </Card>
      )}

      <Tabs defaultValue="menu" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 bg-white/90">
          <TabsTrigger value="menu">Food Menu</TabsTrigger>
          <TabsTrigger value="books">Rent a Book</TabsTrigger>
        </TabsList>

      <TabsContent value="menu" className="space-y-6">
        <Card className="p-6 bg-white/90">
          <h2 className="text-amber-900 mb-4">Food & Beverages Menu</h2>
          <p className="text-amber-700 mb-6">Add items to your cart</p>

          {categories.map(category => (
            <div key={category} className="mb-8 last:mb-0">
              <h3 className="text-amber-900 mb-4">{category}</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {menu
                  .filter(item => item.category === category)
                  .map(item => {
                    const cartQty = getCartQuantity(item.id);
                    return (
                      <Card key={item.id} className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex-1">
                            <h4 className="text-amber-900">{item.name}</h4>
                            <p className="text-amber-700">{item.description}</p>
                          </div>
                          <span className="text-amber-900 ml-4">${item.price.toFixed(2)}</span>
                        </div>

                        {cartQty > 0 ? (
                          <div className="flex items-center gap-3 mt-3">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => onUpdateQuantity(item.id, cartQty - 1)}
                            >
                              <Minus className="w-4 h-4" />
                            </Button>
                            <span className="text-amber-900 min-w-8 text-center">{cartQty}</span>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => onUpdateQuantity(item.id, cartQty + 1)}
                            >
                              <Plus className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => onRemoveFromCart(item.id)}
                              className="ml-auto"
                            >
                              Remove
                            </Button>
                          </div>
                        ) : (
                          <Button
                            size="sm"
                            className="w-full mt-3 bg-gradient-to-r from-amber-500 to-orange-600"
                            onClick={() => onAddToCart({
                              menu_item_id: item.id,
                              name: item.name,
                              price: item.price,
                              quantity: 1
                            })}
                          >
                            <ShoppingCart className="w-4 h-4 mr-2" />
                            Add to Cart
                          </Button>
                        )}
                      </Card>
                    );
                  })}
              </div>
            </div>
          ))}
        </Card>

        {cart.length > 0 && (
          <Card className="p-6 bg-white/90">
            <h3 className="text-amber-900 mb-4">Your Cart</h3>
            <div className="space-y-3">
              {cart.map(item => (
                <div key={item.menu_item_id} className="flex justify-between items-center p-3 bg-amber-50 rounded">
                  <div>
                    <p className="text-amber-900">{item.name}</p>
                    <p className="text-amber-700">Quantity: {item.quantity}</p>
                  </div>
                  <span className="text-amber-900">${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
              <div className="pt-3 border-t border-amber-200">
                <div className="flex justify-between items-center">
                  <span className="text-amber-900">Total:</span>
                  <span className="text-amber-900">
                    ${cart.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </Card>
        )}
      </TabsContent>

      <TabsContent value="books">
        <Card className="p-6 bg-white/90">
          <h2 className="text-amber-900 mb-4">Rent a Book</h2>
          <p className="text-amber-700 mb-6">
            Select a book to rent with your order, or request one separately
          </p>

          <div className="grid md:grid-cols-2 gap-4">
            {books.map(book => (
              <Card
                key={book.id}
                className={`p-4 ${
                  book.available_quantity === 0
                    ? 'opacity-50'
                    : selectedBook === book.id
                    ? 'ring-2 ring-amber-500 bg-amber-50'
                    : ''
                }`}
              >
                <div className="flex gap-4 mb-3">
                  <div className="w-12 h-16 bg-amber-200 rounded flex items-center justify-center flex-shrink-0">
                    <Book className="w-6 h-6 text-amber-700" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-amber-900 mb-1">{book.title}</h4>
                    <p className="text-amber-700 mb-2">by {book.author}</p>
                    <Badge
                      className={
                        book.available_quantity > 0
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }
                    >
                      {book.available_quantity > 0
                        ? `${book.available_quantity} available`
                        : 'Not available'}
                    </Badge>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant={selectedBook === book.id ? "default" : "outline"}
                    onClick={() => {
                      if (book.available_quantity > 0) {
                        onSelectBook(selectedBook === book.id ? null : book.id);
                      }
                    }}
                    disabled={book.available_quantity === 0}
                    className="flex-1"
                  >
                    {selectedBook === book.id ? 'Selected for Order' : 'Add to Order'}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleBookRequest(book.id)}
                    className="flex-1"
                  >
                    <Book className="w-4 h-4 mr-1" />
                    Request Only
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          {selectedBook && (
            <Card className="mt-6 p-4 bg-green-50 border-green-300">
              <div className="flex items-center gap-3 text-green-800">
                <Book className="w-5 h-5" />
                <p>
                  Book selected for your order: {books.find(b => b.id === selectedBook)?.title}
                </p>
              </div>
            </Card>
          )}
        </Card>
      </TabsContent>
    </Tabs>
    </div>
  );
}
