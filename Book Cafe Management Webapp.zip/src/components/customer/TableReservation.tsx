import { useState, useEffect } from 'react';
import { Users, CheckCircle, Clock } from 'lucide-react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface Table {
  id: string;
  table_number: number;
  capacity: number;
  status: 'available' | 'reserved' | 'occupied';
}

interface TableReservationProps {
  accessToken: string;
  selectedTable: string | null;
  onSelectTable: (tableId: string | null) => void;
  refreshTrigger?: number;
}

export function TableReservation({ accessToken, selectedTable, onSelectTable, refreshTrigger }: TableReservationProps) {
  const [tables, setTables] = useState<Table[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [partySize, setPartySize] = useState<number>(2);
  const [showWaitingList, setShowWaitingList] = useState(false);
  const [waitingListSuccess, setWaitingListSuccess] = useState(false);

  const fetchTables = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/tables`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        console.error(`HTTP error! status: ${response.status}`);
        setError('Unable to connect to server. Please check your connection.');
        setTables([]);
        setLoading(false);
        return;
      }

      const data = await response.json();
      
      if (data.error) {
        console.error('API error:', data.error);
        if (data.error.includes('relation') || data.error.includes('does not exist')) {
          setError('Database not set up. Please run the migration script (see console for details)');
          console.warn('⚠️ Database tables not set up. Please run the migration script from /supabase/migrations/schema.sql');
        } else {
          setError(data.error);
        }
      } else {
        setError(null);
      }
      
      setTables(data.tables || []);
    } catch (error) {
      console.error('Error fetching tables:', error);
      setError('Failed to fetch tables. Please try again.');
      setTables([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTables();
    // Refresh tables every 5 seconds
    const interval = setInterval(fetchTables, 5000);
    return () => clearInterval(interval);
  }, [refreshTrigger]);

  const handleJoinWaitingList = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/waiting-list`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ party_size: partySize }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to join waiting list');
      }

      setWaitingListSuccess(true);
      setShowWaitingList(false);
      setTimeout(() => setWaitingListSuccess(false), 5000);
    } catch (error) {
      console.error('Error joining waiting list:', error);
      setError('Failed to join waiting list. Please try again.');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'reserved':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'occupied':
        return 'bg-red-100 text-red-800 border-red-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const availableTablesCount = tables.filter(t => t.status === 'available').length;

  if (loading) {
    return (
      <Card className="p-8 text-center bg-white/90">
        <p className="text-amber-700">Loading tables...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {waitingListSuccess && (
        <Card className="p-4 bg-green-50 border-green-300">
          <div className="flex items-center gap-3 text-green-800">
            <CheckCircle className="w-5 h-5" />
            <p>Successfully added to waiting list! We'll notify you when a table becomes available.</p>
          </div>
        </Card>
      )}

      {error && (
        <Card className="p-4 bg-red-50 border-red-200">
          <div className="flex items-start gap-3">
            <div className="text-red-600">⚠️</div>
            <div className="flex-1">
              <p className="text-red-800 mb-2">{error}</p>
              {error.includes('Database not set up') && (
                <div className="text-red-700 bg-red-100 p-3 rounded mt-2">
                  <p className="mb-2"><strong>Setup Required:</strong></p>
                  <ol className="list-decimal list-inside space-y-1 text-sm">
                    <li>Open your Supabase SQL Editor</li>
                    <li>Copy contents of /supabase/migrations/schema.sql</li>
                    <li>Paste and run in SQL Editor</li>
                    <li>Refresh this page</li>
                  </ol>
                  <p className="mt-2 text-sm">See SETUP_INSTRUCTIONS.md for details</p>
                </div>
              )}
            </div>
          </div>
        </Card>
      )}

      <Card className="p-6 bg-white/90">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-amber-900">Select Your Table</h2>
            <p className="text-amber-700 mt-1">
              {availableTablesCount > 0 
                ? `${availableTablesCount} table(s) available`
                : 'All tables are currently occupied'}
            </p>
          </div>
          {availableTablesCount === 0 && !showWaitingList && (
            <Button
              onClick={() => setShowWaitingList(true)}
              className="bg-gradient-to-r from-amber-500 to-orange-600"
            >
              <Clock className="w-4 h-4 mr-2" />
              Join Waiting List
            </Button>
          )}
        </div>

        {showWaitingList && (
          <Card className="p-4 bg-amber-50 border-amber-300 mb-6">
            <h3 className="text-amber-900 mb-4">Join Waiting List</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="partySize">Number of People</Label>
                <Input
                  id="partySize"
                  type="number"
                  min="1"
                  max="10"
                  value={partySize}
                  onChange={(e) => setPartySize(parseInt(e.target.value) || 2)}
                  className="mt-1"
                />
              </div>
              <div className="flex gap-3">
                <Button
                  onClick={handleJoinWaitingList}
                  className="flex-1 bg-gradient-to-r from-amber-500 to-orange-600"
                >
                  Confirm
                </Button>
                <Button
                  onClick={() => setShowWaitingList(false)}
                  variant="outline"
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </Card>
        )}

        {tables.length === 0 && !loading && (
          <div className="text-center py-8">
            <p className="text-amber-700">No tables available at the moment.</p>
            <p className="text-amber-600 text-sm mt-2">
              {error ? 'Please resolve the error above.' : 'Please check back later.'}
            </p>
          </div>
        )}

        <div className="grid md:grid-cols-3 gap-4">
          {tables.map((table) => (
            <Card
              key={table.id}
              className={`p-6 cursor-pointer transition-all ${
                table.status !== 'available'
                  ? 'opacity-50 cursor-not-allowed'
                  : selectedTable === table.id
                  ? 'ring-2 ring-amber-500 bg-amber-50'
                  : 'hover:shadow-lg'
              }`}
              onClick={() => {
                if (table.status === 'available') {
                  onSelectTable(selectedTable === table.id ? null : table.id);
                }
              }}
            >
              <div className="text-center">
                <div className="flex items-center justify-center mb-3">
                  <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center">
                    <span className="text-amber-900">{table.table_number}</span>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-2 mb-3">
                  <Users className="w-4 h-4 text-amber-700" />
                  <span className="text-amber-900">Capacity: {table.capacity}</span>
                </div>

                <Badge className={getStatusColor(table.status)}>
                  {table.status}
                </Badge>

                {selectedTable === table.id && (
                  <div className="mt-3 flex items-center justify-center gap-2 text-green-700">
                    <CheckCircle className="w-5 h-5" />
                    <span>Selected</span>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      </Card>

      {selectedTable && (
        <Card className="p-4 bg-green-50 border-green-300">
          <div className="flex items-center justify-center gap-3 text-green-800">
            <CheckCircle className="w-5 h-5" />
            <p>
              Table {tables.find(t => t.id === selectedTable)?.table_number} selected! 
              You can now proceed to order food.
            </p>
          </div>
        </Card>
      )}
    </div>
  );
}
