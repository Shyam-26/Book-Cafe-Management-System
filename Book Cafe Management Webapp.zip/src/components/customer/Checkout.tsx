import { useState } from 'react';
import { ArrowLeft, CreditCard, CheckCircle } from 'lucide-react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import { projectId, publicAnonKey } from '../../utils/supabase/info';
import type { CartItem } from './CustomerDashboard';

interface CheckoutProps {
  user: any;
  accessToken: string;
  tableId: string;
  cart: CartItem[];
  bookId: string | null;
  totalAmount: number;
  onBack: () => void;
  onComplete: () => void;
}

export function Checkout({
  user,
  accessToken,
  tableId,
  cart,
  bookId,
  totalAmount,
  onBack,
  onComplete
}: CheckoutProps) {
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setProcessing(true);

    try {
      // Create order
      const orderResponse = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/orders`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            table_id: tableId,
            items: cart.map(item => ({
              menu_item_id: item.menu_item_id,
              quantity: item.quantity
            })),
            book_id: bookId
          }),
        }
      );

      const orderData = await orderResponse.json();

      if (!orderResponse.ok) {
        throw new Error(orderData.error || 'Failed to create order');
      }

      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Create payment
      const paymentResponse = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/payments`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            order_id: orderData.order.id,
            amount: totalAmount,
            payment_method: paymentMethod
          }),
        }
      );

      const paymentData = await paymentResponse.json();

      if (!paymentResponse.ok) {
        throw new Error(paymentData.error || 'Payment failed');
      }

      setSuccess(true);

      // Redirect after 3 seconds
      setTimeout(() => {
        onComplete();
      }, 3000);
    } catch (error: any) {
      console.error('Checkout error:', error);
      alert(error.message || 'Payment failed. Please try again.');
      setProcessing(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md w-full p-8 text-center bg-white/90">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-12 h-12 text-green-600" />
          </div>
          <h2 className="text-green-900 mb-4">Payment Successful!</h2>
          <p className="text-green-700 mb-6">
            Your order has been placed successfully. Our staff will prepare your order shortly.
          </p>
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-green-800">
              Total Paid: <strong>${totalAmount.toFixed(2)}</strong>
            </p>
          </div>
          <p className="text-green-700 mt-4">Redirecting to order history...</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-4xl mx-auto">
        <Card className="p-6 bg-white/90 mb-6">
          <Button variant="ghost" onClick={onBack} className="mb-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Order
          </Button>

          <h2 className="text-amber-900 mb-6">Checkout</h2>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-amber-900 mb-4">Order Summary</h3>
              <div className="space-y-3 mb-6">
                {cart.map(item => (
                  <div key={item.menu_item_id} className="flex justify-between items-center p-3 bg-amber-50 rounded">
                    <div>
                      <p className="text-amber-900">{item.name}</p>
                      <p className="text-amber-700">Qty: {item.quantity} × ${item.price.toFixed(2)}</p>
                    </div>
                    <span className="text-amber-900">${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-amber-200">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-amber-900">Subtotal:</span>
                  <span className="text-amber-900">${totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-amber-900">Tax (10%):</span>
                  <span className="text-amber-900">${(totalAmount * 0.1).toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-amber-200">
                  <span className="text-amber-900">Total:</span>
                  <span className="text-amber-900">${(totalAmount * 1.1).toFixed(2)}</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-amber-900 mb-4">Payment Details</h3>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label>Payment Method</Label>
                  <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="card" id="card" />
                      <Label htmlFor="card" className="cursor-pointer">Credit/Debit Card</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="cash" id="cash" />
                      <Label htmlFor="cash" className="cursor-pointer">Cash</Label>
                    </div>
                  </RadioGroup>
                </div>

                {paymentMethod === 'card' && (
                  <>
                    <div>
                      <Label htmlFor="cardName">Cardholder Name</Label>
                      <Input
                        id="cardName"
                        value={cardName}
                        onChange={(e) => setCardName(e.target.value)}
                        placeholder="John Doe"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="cardNumber">Card Number</Label>
                      <Input
                        id="cardNumber"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        placeholder="1234 5678 9012 3456"
                        required
                        maxLength={19}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="expiryDate">Expiry Date</Label>
                        <Input
                          id="expiryDate"
                          value={expiryDate}
                          onChange={(e) => setExpiryDate(e.target.value)}
                          placeholder="MM/YY"
                          required
                          maxLength={5}
                        />
                      </div>
                      <div>
                        <Label htmlFor="cvv">CVV</Label>
                        <Input
                          id="cvv"
                          type="password"
                          value={cvv}
                          onChange={(e) => setCvv(e.target.value)}
                          placeholder="123"
                          required
                          maxLength={3}
                        />
                      </div>
                    </div>
                  </>
                )}

                <div className="pt-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg mb-4">
                    <p className="text-blue-800">
                      <strong>Note:</strong> This is a demo payment page. No real payment will be processed.
                    </p>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                    disabled={processing}
                  >
                    {processing ? (
                      'Processing...'
                    ) : (
                      <>
                        <CreditCard className="w-4 h-4 mr-2" />
                        Pay ${(totalAmount * 1.1).toFixed(2)}
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
