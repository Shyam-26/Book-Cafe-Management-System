import { useState, useEffect } from 'react';
import { Clock, CheckCircle, XCircle, Package } from 'lucide-react';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { projectId } from '../../utils/supabase/info';

interface Order {
  id: string;
  table_id: string;
  staff_id: string | null;
  order_items: Array<{
    menu_item_id: string;
    quantity: number;
    price: number;
  }>;
  book_id: string | null;
  status: string;
  total_amount: number;
  created_at: string;
  staff?: {
    name: string;
  };
  cafe_table?: {
    table_number: number;
  };
}

interface OrderHistoryProps {
  user: any;
  accessToken: string;
}

export function OrderHistory({ user, accessToken }: OrderHistoryProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchOrders = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/orders`,
        {
          headers: {
            'Authorization': `Bearer ${accessToken}`,
          },
        }
      );

      const data = await response.json();
      setOrders(data.orders || []);
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
    // Refresh orders every 5 seconds to see staff updates
    const interval = setInterval(fetchOrders, 5000);
    return () => clearInterval(interval);
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-600" />;
      case 'taken':
        return <Package className="w-5 h-5 text-orange-600" />;
      case 'preparing':
        return <Package className="w-5 h-5 text-blue-600" />;
      case 'served':
        return <CheckCircle className="w-5 h-5 text-purple-600" />;
      default:
        return <XCircle className="w-5 h-5 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'taken':
        return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'preparing':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'served':
        return 'bg-purple-100 text-purple-800 border-purple-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getStatusMessage = (status: string, staffName?: string) => {
    switch (status) {
      case 'pending':
        return '⏳ Your order is pending. Staff will take it soon.';
      case 'taken':
        return `✋ Order taken by ${staffName || 'staff'}. Preparation will start shortly.`;
      case 'preparing':
        return `👨‍🍳 ${staffName || 'Staff'} is preparing your order!`;
      case 'served':
        return '🍽️ Your order has been served. Enjoy your meal!';
      case 'completed':
        return '✅ Order completed. Thank you!';
      default:
        return '';
    }
  };

  if (loading) {
    return (
      <Card className="p-8 text-center bg-white/90">
        <p className="text-amber-700">Loading order history...</p>
      </Card>
    );
  }

  if (orders.length === 0) {
    return (
      <Card className="p-8 text-center bg-white/90">
        <p className="text-amber-700">No orders yet. Start by selecting a table and ordering some food!</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-white/90">
        <h2 className="text-amber-900 mb-6">Your Order History</h2>

        <div className="space-y-4">
          {orders.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()).map((order) => (
            <Card key={order.id} className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    {getStatusIcon(order.status)}
                    <h3 className="text-amber-900">Order #{order.id.slice(-8)}</h3>
                  </div>
                  <p className="text-amber-700">
                    {new Date(order.created_at).toLocaleString()}
                  </p>
                </div>
                <Badge className={getStatusColor(order.status)}>
                  {order.status}
                </Badge>
              </div>

              <div className="space-y-2 mb-4">
                <p className="text-amber-700">
                  <strong>Table:</strong> {order.cafe_table?.table_number || 'N/A'}
                </p>
                <p className="text-amber-700">
                  <strong>Items:</strong> {order.order_items?.length || 0} item(s)
                </p>
                {order.book_id && (
                  <p className="text-amber-700">
                    <strong>Book Rental:</strong> Included
                  </p>
                )}
                {order.staff && (
                  <p className="text-amber-700">
                    <strong>Assigned Staff:</strong> {order.staff.name}
                  </p>
                )}
              </div>

              <div className="pt-4 border-t border-amber-200">
                <div className="flex justify-between items-center">
                  <span className="text-amber-900">Total Amount:</span>
                  <span className="text-amber-900">${order.total_amount.toFixed(2)}</span>
                </div>
              </div>

              {order.status !== 'completed' && (
                <div className={`mt-4 p-3 border rounded ${
                  order.status === 'pending' ? 'bg-yellow-50 border-yellow-200' :
                  order.status === 'taken' ? 'bg-orange-50 border-orange-200' :
                  order.status === 'preparing' ? 'bg-blue-50 border-blue-200' :
                  'bg-purple-50 border-purple-200'
                }`}>
                  <p className={
                    order.status === 'pending' ? 'text-yellow-800' :
                    order.status === 'taken' ? 'text-orange-800' :
                    order.status === 'preparing' ? 'text-blue-800' :
                    'text-purple-800'
                  }>
                    {getStatusMessage(order.status, order.staff?.name)}
                  </p>
                </div>
              )}

              {order.status === 'completed' && (
                <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded">
                  <p className="text-green-800">
                    {getStatusMessage(order.status)}
                  </p>
                </div>
              )}
            </Card>
          ))}
        </div>
      </Card>
    </div>
  );
}
