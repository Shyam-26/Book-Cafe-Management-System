import { useState, useEffect } from 'react';
import { Coffee, LogOut, ShoppingCart, History } from 'lucide-react';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { TableReservation } from './TableReservation';
import { MenuOrdering } from './MenuOrdering';
import { Checkout } from './Checkout';
import { OrderHistory } from './OrderHistory';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
}

interface CustomerDashboardProps {
  user: User;
  accessToken: string;
  onLogout: () => void;
}

export interface CartItem {
  menu_item_id: string;
  name: string;
  price: number;
  quantity: number;
}

export function CustomerDashboard({ user, accessToken, onLogout }: CustomerDashboardProps) {
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedBook, setSelectedBook] = useState<string | null>(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const [activeTab, setActiveTab] = useState('table');
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const addToCart = (item: CartItem) => {
    const existingItem = cart.find(i => i.menu_item_id === item.menu_item_id);
    if (existingItem) {
      setCart(cart.map(i =>
        i.menu_item_id === item.menu_item_id
          ? { ...i, quantity: i.quantity + item.quantity }
          : i
      ));
    } else {
      setCart([...cart, item]);
    }
  };

  const removeFromCart = (menuItemId: string) => {
    setCart(cart.filter(i => i.menu_item_id !== menuItemId));
  };

  const updateCartQuantity = (menuItemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(menuItemId);
    } else {
      setCart(cart.map(i =>
        i.menu_item_id === menuItemId ? { ...i, quantity } : i
      ));
    }
  };

  const totalAmount = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleCheckoutComplete = () => {
    setCart([]);
    setSelectedTable(null);
    setSelectedBook(null);
    setShowCheckout(false);
    setActiveTab('history');
    // Force refresh of tables to show updated availability
    setRefreshTrigger(prev => prev + 1);
  };

  if (showCheckout) {
    return (
      <Checkout
        user={user}
        accessToken={accessToken}
        tableId={selectedTable!}
        cart={cart}
        bookId={selectedBook}
        totalAmount={totalAmount}
        onBack={() => setShowCheckout(false)}
        onComplete={handleCheckoutComplete}
      />
    );
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white/90 backdrop-blur rounded-lg shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Coffee className="w-10 h-10 text-amber-700" />
              <div>
                <h1 className="text-amber-900">Welcome, {user.name}!</h1>
                <p className="text-amber-700">Customer Dashboard</p>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={onLogout}
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        {cart.length > 0 && (
          <div className="bg-amber-100 border border-amber-300 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <ShoppingCart className="w-5 h-5 text-amber-700" />
                <span className="text-amber-900">
                  {cart.length} item(s) in cart - Total: ${totalAmount.toFixed(2)}
                </span>
              </div>
              <Button
                className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700"
                onClick={() => {
                  if (!selectedTable) {
                    alert('Please select a table first');
                    setActiveTab('table');
                  } else {
                    setShowCheckout(true);
                  }
                }}
              >
                Proceed to Checkout
              </Button>
            </div>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 bg-white/90">
            <TabsTrigger value="order">Order Food & Reserve Table</TabsTrigger>
            <TabsTrigger value="history">Order History</TabsTrigger>
          </TabsList>

          <TabsContent value="order">
            <div className="space-y-6">
              <TableReservation
                accessToken={accessToken}
                selectedTable={selectedTable}
                onSelectTable={setSelectedTable}
                refreshTrigger={refreshTrigger}
              />
              <MenuOrdering
                accessToken={accessToken}
                cart={cart}
                selectedBook={selectedBook}
                onAddToCart={addToCart}
                onRemoveFromCart={removeFromCart}
                onUpdateQuantity={updateCartQuantity}
                onSelectBook={setSelectedBook}
              />
            </div>
          </TabsContent>

          <TabsContent value="history">
            <OrderHistory
              user={user}
              accessToken={accessToken}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
