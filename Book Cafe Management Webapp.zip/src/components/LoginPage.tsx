import { useState } from 'react';
import { ArrowLeft, Coffee } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface LoginPageProps {
  role: 'customer' | 'staff' | 'manager';
  onLoginSuccess: (user: any, token: string) => void;
  onBack: () => void;
}

export function LoginPage({ role, onLoginSuccess, onBack }: LoginPageProps) {
  const [isSignup, setIsSignup] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isSignup) {
        // Signup
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/signup`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${publicAnonKey}`,
            },
            body: JSON.stringify({ email, password, name, role }),
          }
        );

        const data = await response.json();

        if (!response.ok) {
          // If email already exists, suggest switching to login
          if (data.errorCode === 'EMAIL_EXISTS') {
            setError(data.error);
            // Automatically switch to login mode after showing error
            setTimeout(() => {
              setIsSignup(false);
              setError('');
            }, 3000);
            setLoading(false);
            return;
          }
          throw new Error(data.error || 'Signup failed');
        }

        // Auto-login after signup
        const loginResponse = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/signin`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${publicAnonKey}`,
            },
            body: JSON.stringify({ email, password }),
          }
        );

        const loginData = await loginResponse.json();

        if (!loginResponse.ok) {
          throw new Error(loginData.error || 'Login failed');
        }

        onLoginSuccess(loginData.user, loginData.access_token);
      } else {
        // Signin
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/signin`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${publicAnonKey}`,
            },
            body: JSON.stringify({ email, password }),
          }
        );

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.error || 'Login failed');
        }

        if (data.user.role !== role) {
          throw new Error(`Invalid credentials. Please use ${role} login.`);
        }

        onLoginSuccess(data.user, data.access_token);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const roleColors = {
    customer: 'from-amber-500 to-orange-600',
    staff: 'from-blue-500 to-indigo-600',
    manager: 'from-purple-500 to-pink-600'
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <Card className="max-w-md w-full p-8 bg-white/90 backdrop-blur">
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>

        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Coffee className="w-12 h-12 text-amber-700" />
          </div>
          <h2 className="text-amber-900 mb-2 capitalize">{role} {isSignup ? 'Sign Up' : 'Login'}</h2>
          <p className="text-amber-700">
            {isSignup ? 'Create your account' : 'Welcome back'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignup && (
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                placeholder="Enter your name"
              />
            </div>
          )}

          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="Enter your email"
            />
          </div>

          <div>
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="Enter your password"
            />
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-700">{error}</p>
            </div>
          )}

          <Button
            type="submit"
            className={`w-full bg-gradient-to-r ${roleColors[role]} hover:opacity-90`}
            disabled={loading}
          >
            {loading ? 'Processing...' : isSignup ? 'Create Account' : 'Login'}
          </Button>

          <Button
            type="button"
            variant="outline"
            className="w-full"
            onClick={() => {
              setIsSignup(!isSignup);
              setError('');
            }}
          >
            {isSignup ? 'Already have an account? Login' : 'Create New Account'}
          </Button>
        </form>

        {!isSignup && (
          <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <p className="text-amber-800">
              <strong>Demo Credentials:</strong><br />
              Create a new account or use existing credentials
            </p>
          </div>
        )}
      </Card>
    </div>
  );
}
