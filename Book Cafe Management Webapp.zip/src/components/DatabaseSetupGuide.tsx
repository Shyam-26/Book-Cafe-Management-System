import { AlertCircle, Database, CheckCircle, Copy } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { useState } from 'react';

export function DatabaseSetupGuide() {
  const [copied, setCopied] = useState(false);

  const handleCopySQL = async () => {
    const sqlScript = `-- Run this entire script in your Supabase SQL Editor

-- Users table (extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('customer', 'staff', 'manager')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Tables in the cafe
CREATE TABLE IF NOT EXISTS public.cafe_tables (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  table_number INTEGER NOT NULL UNIQUE,
  capacity INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'reserved', 'occupied')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.cafe_tables ENABLE ROW LEVEL SECURITY;

-- Menu items
CREATE TABLE IF NOT EXISTS public.menu_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  category TEXT NOT NULL,
  available BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.menu_items ENABLE ROW LEVEL SECURITY;

-- Books available for rent
CREATE TABLE IF NOT EXISTS public.books (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 0,
  available_quantity INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.books ENABLE ROW LEVEL SECURITY;

-- Orders
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES public.users(id),
  table_id UUID NOT NULL REFERENCES public.cafe_tables(id),
  book_id UUID REFERENCES public.books(id),
  staff_id UUID REFERENCES public.users(id),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'taken', 'preparing', 'served', 'completed')),
  total_amount DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Order items (items in each order)
CREATE TABLE IF NOT EXISTS public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  menu_item_id UUID NOT NULL REFERENCES public.menu_items(id),
  quantity INTEGER NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

-- Payments
CREATE TABLE IF NOT EXISTS public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id),
  customer_id UUID NOT NULL REFERENCES public.users(id),
  amount DECIMAL(10, 2) NOT NULL,
  payment_method TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

-- Table waiting list (for when tables are full)
CREATE TABLE IF NOT EXISTS public.table_waiting_list (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES public.users(id),
  customer_name TEXT NOT NULL,
  party_size INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting', 'notified', 'cancelled', 'seated')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.table_waiting_list ENABLE ROW LEVEL SECURITY;

-- Book requests (for standalone book reservations)
CREATE TABLE IF NOT EXISTS public.book_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES public.users(id),
  customer_name TEXT NOT NULL,
  book_id UUID NOT NULL REFERENCES public.books(id),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'served')),
  staff_id UUID REFERENCES public.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.book_requests ENABLE ROW LEVEL SECURITY;

-- RLS Policies (allow all for service role)
CREATE POLICY "Allow all for service role" ON public.users FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.cafe_tables FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.menu_items FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.books FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.orders FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.order_items FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.payments FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.table_waiting_list FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON public.book_requests FOR ALL USING (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON public.orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_staff_id ON public.orders(staff_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON public.order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_payments_customer_id ON public.payments(customer_id);
CREATE INDEX IF NOT EXISTS idx_users_role ON public.users(role);
CREATE INDEX IF NOT EXISTS idx_table_waiting_list_status ON public.table_waiting_list(status);
CREATE INDEX IF NOT EXISTS idx_book_requests_status ON public.book_requests(status);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers to automatically update updated_at
CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_table_waiting_list_updated_at
  BEFORE UPDATE ON public.table_waiting_list
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_book_requests_updated_at
  BEFORE UPDATE ON public.book_requests
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert default data
INSERT INTO public.cafe_tables (table_number, capacity, status) VALUES
  (1, 2, 'available'),
  (2, 4, 'available'),
  (3, 2, 'available'),
  (4, 6, 'available'),
  (5, 4, 'available'),
  (6, 2, 'available')
ON CONFLICT (table_number) DO NOTHING;

INSERT INTO public.menu_items (name, description, price, category, available) VALUES
  ('Espresso', 'Strong coffee', 3.50, 'Beverages', TRUE),
  ('Cappuccino', 'Coffee with steamed milk', 4.50, 'Beverages', TRUE),
  ('Green Tea', 'Organic green tea', 3.00, 'Beverages', TRUE),
  ('Chocolate Cake', 'Rich chocolate cake', 5.50, 'Desserts', TRUE),
  ('Croissant', 'Buttery croissant', 3.50, 'Pastries', TRUE),
  ('Caesar Salad', 'Fresh caesar salad', 8.50, 'Mains', TRUE),
  ('Club Sandwich', 'Triple decker sandwich', 9.50, 'Mains', TRUE),
  ('Blueberry Muffin', 'Freshly baked muffin', 4.00, 'Pastries', TRUE)
ON CONFLICT DO NOTHING;

INSERT INTO public.books (title, author, quantity, available_quantity) VALUES
  ('The Great Gatsby', 'F. Scott Fitzgerald', 5, 5),
  ('1984', 'George Orwell', 4, 4),
  ('To Kill a Mockingbird', 'Harper Lee', 3, 3),
  ('Pride and Prejudice', 'Jane Austen', 4, 4),
  ('The Catcher in the Rye', 'J.D. Salinger', 3, 3),
  ('Harry Potter', 'J.K. Rowling', 6, 6)
ON CONFLICT DO NOTHING;`;

    try {
      await navigator.clipboard.writeText(sqlScript);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <Card className="p-6 bg-red-50 border-red-300">
      <div className="flex items-start gap-4">
        <AlertCircle className="w-8 h-8 text-red-600 flex-shrink-0 mt-1" />
        <div className="flex-1">
          <h3 className="text-red-900 mb-2 flex items-center gap-2">
            Database Tables Missing
          </h3>
          <p className="text-red-800 mb-4">
            The required database tables <code className="bg-red-100 px-1.5 py-0.5 rounded">table_waiting_list</code> and{' '}
            <code className="bg-red-100 px-1.5 py-0.5 rounded">book_requests</code> are not set up yet.
          </p>
          
          <div className="bg-white p-4 rounded border border-red-200 mb-4">
            <h4 className="text-red-900 mb-3">Setup Instructions:</h4>
            <ol className="space-y-3 text-red-800">
              <li className="flex items-start gap-2">
                <span className="bg-red-100 text-red-900 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm">1</span>
                <div>
                  <strong>Copy the SQL script</strong>
                  <p className="text-sm text-red-700 mt-1">
                    Click the button below to copy the complete database schema
                  </p>
                  <Button
                    onClick={handleCopySQL}
                    variant="outline"
                    size="sm"
                    className="mt-2 border-red-300 hover:bg-red-50"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    {copied ? 'Copied!' : 'Copy SQL Script'}
                  </Button>
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="bg-red-100 text-red-900 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm">2</span>
                <div>
                  <strong>Open Supabase SQL Editor</strong>
                  <p className="text-sm text-red-700">
                    Go to your Supabase dashboard → SQL Editor → New query
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="bg-red-100 text-red-900 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm">3</span>
                <div>
                  <strong>Run the migration</strong>
                  <p className="text-sm text-red-700">
                    Paste the copied SQL and click "Run" or press Cmd/Ctrl + Enter
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="bg-red-100 text-red-900 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm">4</span>
                <div>
                  <strong>Refresh this page</strong>
                  <p className="text-sm text-red-700">
                    Once you see "Success. No rows returned", refresh your browser
                  </p>
                </div>
              </li>
            </ol>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded p-3 mb-4">
            <div className="flex items-start gap-2">
              <Database className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-blue-900">
                  <strong>What this creates:</strong>
                </p>
                <ul className="text-sm text-blue-800 mt-1 space-y-1">
                  <li>• 9 database tables (users, cafe_tables, menu_items, books, orders, order_items, payments, table_waiting_list, book_requests)</li>
                  <li>• Default data (6 cafe tables, 8 menu items, 6 books)</li>
                  <li>• Performance indexes on key columns</li>
                  <li>• Row-level security policies</li>
                  <li>• Automatic timestamp update triggers</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={() => window.open('https://supabase.com/dashboard/project/_/sql', '_blank')}
              className="bg-red-600 hover:bg-red-700"
            >
              <Database className="w-4 h-4 mr-2" />
              Open SQL Editor
            </Button>
            <Button
              variant="outline"
              onClick={() => window.location.reload()}
            >
              Refresh Page
            </Button>
          </div>

          <p className="text-sm text-red-700 mt-4">
            💡 <strong>Tip:</strong> The SQL script uses "CREATE IF NOT EXISTS" so it's safe to run multiple times.
          </p>
        </div>
      </div>
    </Card>
  );
}
