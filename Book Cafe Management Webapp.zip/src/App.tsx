import { useState, useEffect } from 'react';
import { HomePage } from './components/HomePage';
import { LoginPage } from './components/LoginPage';
import { CustomerDashboard } from './components/customer/CustomerDashboard';
import { StaffDashboard } from './components/staff/StaffDashboard';
import { ManagerDashboard } from './components/manager/ManagerDashboard';
import { DatabaseSetupGuide } from './components/DatabaseSetupGuide';
import { DatabaseErrorBanner } from './components/DatabaseErrorBanner';
import { projectId, publicAnonKey } from './utils/supabase/info';

type Page = 'home' | 'customer-login' | 'staff-login' | 'manager-login' | 'customer-dashboard' | 'staff-dashboard' | 'manager-dashboard' | 'setup-guide';

interface User {
  id: string;
  email: string;
  name: string;
  role: 'customer' | 'staff' | 'manager';
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string>('');
  const [dbError, setDbError] = useState<boolean>(false);

  // Check database tables on first load
  useEffect(() => {
    const checkDatabase = async () => {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-0c99568f/waiting-list`,
          {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`,
            },
          }
        );
        const data = await response.json();
        
        // Check if we got a database error
        if (data.error) {
          const errorObj = typeof data.error === 'string' ? { message: data.error } : data.error;
          if (
            errorObj.code === 'PGRST205' ||
            (errorObj.message && errorObj.message.includes('Could not find the table'))
          ) {
            setDbError(true);
            console.log('Database tables missing - showing setup guide');
          }
        }
      } catch (error) {
        console.error('Database check error:', error);
      }
    };

    checkDatabase();

    console.log('%c📚 Book Café Management System', 'font-size: 20px; font-weight: bold; color: #92400e;');
    console.log('%c🔧 Setup Guide:', 'font-size: 14px; font-weight: bold; color: #d97706;');
    console.log('1. Run the database migration script from /supabase/migrations/schema.sql');
    console.log('2. Deploy the Edge Function from /supabase/functions/server/');
    console.log('3. See SETUP_INSTRUCTIONS.md for detailed steps');
    console.log('%c❓ Having issues? Check TROUBLESHOOTING.md', 'color: #059669;');
  }, []);

  const handleRoleSelect = (role: 'customer' | 'staff' | 'manager') => {
    setCurrentPage(`${role}-login` as Page);
  };

  const handleLoginSuccess = (userData: User, token: string) => {
    setUser(userData);
    setAccessToken(token);
    setCurrentPage(`${userData.role}-dashboard` as Page);
  };

  const handleLogout = () => {
    setUser(null);
    setAccessToken('');
    setCurrentPage('home');
  };

  const handleBackToLogin = () => {
    if (user) {
      setCurrentPage(`${user.role}-login` as Page);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-100">
      {dbError && <DatabaseErrorBanner onViewGuide={() => setCurrentPage('setup-guide')} />}

      {currentPage === 'setup-guide' && (
        <div className="p-6 max-w-4xl mx-auto pt-12">
          <DatabaseSetupGuide />
          <div className="mt-6 text-center">
            <button
              onClick={() => setCurrentPage('home')}
              className="text-amber-700 hover:text-amber-900 underline"
            >
              ← Back to Home
            </button>
          </div>
        </div>
      )}

      {currentPage === 'home' && (
        <HomePage onRoleSelect={handleRoleSelect} />
      )}

      {currentPage === 'customer-login' && (
        <LoginPage
          role="customer"
          onLoginSuccess={handleLoginSuccess}
          onBack={() => setCurrentPage('home')}
        />
      )}

      {currentPage === 'staff-login' && (
        <LoginPage
          role="staff"
          onLoginSuccess={handleLoginSuccess}
          onBack={() => setCurrentPage('home')}
        />
      )}

      {currentPage === 'manager-login' && (
        <LoginPage
          role="manager"
          onLoginSuccess={handleLoginSuccess}
          onBack={() => setCurrentPage('home')}
        />
      )}

      {currentPage === 'customer-dashboard' && user && (
        <CustomerDashboard
          user={user}
          accessToken={accessToken}
          onLogout={handleLogout}
        />
      )}

      {currentPage === 'staff-dashboard' && user && (
        <StaffDashboard
          user={user}
          accessToken={accessToken}
          onLogout={handleLogout}
        />
      )}

      {currentPage === 'manager-dashboard' && user && (
        <ManagerDashboard
          user={user}
          accessToken={accessToken}
          onLogout={handleLogout}
        />
      )}
    </div>
  );
}
