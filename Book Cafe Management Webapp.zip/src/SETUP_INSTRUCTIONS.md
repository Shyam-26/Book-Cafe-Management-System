# 🚀 Book Cafe Management System - Complete Setup Guide

## Prerequisites
- Access to your Supabase project dashboard
- The application is already deployed in Figma Make

> 💡 **Having issues?** See [TROUBLESHOOTING.md](TROUBLESHOOTING.md) for common problems and solutions

## Step-by-Step Setup

### 1️⃣ Open Supabase SQL Editor

1. Go to [https://supabase.com/dashboard](https://supabase.com/dashboard)
2. Select your project
3. Click **"SQL Editor"** in the left sidebar (icon looks like `</>`)
4. Click **"New query"** button

### 2️⃣ Run the Database Migration

1. Open the file `/supabase/migrations/schema.sql` in this project
2. **Copy the ENTIRE contents** of that file
3. **Paste** into the SQL Editor in Supabase
4. Click **"Run"** button (or press Cmd/Ctrl + Enter)
5. Wait for success message: "Success. No rows returned"

**What this does:**
- Creates 7 tables (users, cafe_tables, menu_items, books, orders, order_items, payments)
- Sets up relationships and foreign keys
- Creates indexes for performance
- Enables Row Level Security
- Inserts default data (6 tables, 8 menu items, 6 books)

### 3️⃣ Verify the Setup

Run this query to confirm all tables were created:

```sql
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
ORDER BY table_name;
```

You should see these 7 tables:
- ✅ books
- ✅ cafe_tables
- ✅ menu_items
- ✅ order_items
- ✅ orders
- ✅ payments
- ✅ users

### 4️⃣ Check Default Data

Run these queries to verify default data was inserted:

```sql
-- Should return 6 tables
SELECT COUNT(*) FROM cafe_tables;

-- Should return 8 menu items
SELECT COUNT(*) FROM menu_items;

-- Should return 6 books
SELECT COUNT(*) FROM books;
```

### 5️⃣ Test the Application

Now you're ready to test! Follow this workflow:

#### As a Customer:
1. Click "Customer" on home page
2. Click "Create New Account"
3. Fill in details (use any email/password)
4. After signup, you'll auto-login
5. **Select Table** tab: Choose an available table
6. **Order Food & Books** tab: Add items to cart, optionally rent a book
7. Click "Proceed to Checkout"
8. Fill in dummy payment details and submit
9. **Order History** tab: See your order with real-time status

#### As a Staff Member:
1. Logout (if logged in)
2. Click "Staff" on home page
3. Create a staff account
4. **Food Serving** tab: You'll see the customer's order
5. Click "Take Order" (status changes to "taken")
6. Click "Start Preparing" (status → "preparing")
7. Click "Mark as Served" (status → "served")
8. Check **Table Allotment** tab to see table status
9. Check **Book Serving** tab to see book rentals

#### As a Manager:
1. Logout
2. Click "Manager" on home page
3. Create a manager account
4. **Analytics** tab: View revenue, orders, customer stats
5. **Books** tab: Add/remove books, adjust quantities
6. **Menu** tab: Add/edit/delete menu items
7. **Staff** tab: Add new staff, remove existing staff

### 6️⃣ Test Real-time Updates

1. Open two browser windows side-by-side
2. Window 1: Login as Customer, place an order
3. Window 2: Login as Staff
4. Watch the order appear in staff dashboard (within 5 seconds)
5. Take the order in Window 2
6. Watch status update in Window 1's order history

## 🎯 Key Features to Test

### Order Assignment System
- [ ] Multiple staff can see pending orders
- [ ] Only one staff can "take" an order
- [ ] Other staff cannot take the same order
- [ ] Customer sees assigned staff name
- [ ] Status flow: pending → taken → preparing → served → completed

### Table Reservations
- [ ] Customer selects table, status changes to "occupied"
- [ ] Staff can see all table statuses in real-time
- [ ] After payment, table returns to "available"

### Staff Management
- [ ] Manager can add new staff members
- [ ] Manager can delete staff members
- [ ] Staff list updates in real-time

### Real-time Sync
- [ ] Customer order history refreshes every 5 seconds
- [ ] Staff dashboard refreshes every 5 seconds
- [ ] Status changes visible to all users

## 📊 Useful SQL Queries

Copy these into SQL Editor to inspect your data:

### View All Orders with Details
```sql
SELECT 
  o.id,
  c.name as customer,
  s.name as staff,
  ct.table_number,
  o.status,
  o.total_amount,
  o.created_at
FROM orders o
LEFT JOIN users c ON o.customer_id = c.id
LEFT JOIN users s ON o.staff_id = s.id
LEFT JOIN cafe_tables ct ON o.table_id = ct.id
ORDER BY o.created_at DESC;
```

### View Today's Revenue
```sql
SELECT 
  COUNT(*) as total_orders,
  SUM(amount) as total_revenue
FROM payments
WHERE DATE(created_at) = CURRENT_DATE;
```

### Check Active Orders
```sql
SELECT status, COUNT(*) as count
FROM orders
WHERE status != 'completed'
GROUP BY status;
```

More queries available in `/supabase/migrations/queries.sql`

## 🔧 Troubleshooting

### Error: "relation already exists"
**Solution:** The tables were already created. You can:
1. Skip the migration (tables exist)
2. Or drop and recreate: Run the reset script from `/DATABASE_SETUP.md`

### Error: "permission denied"
**Solution:** Make sure you're using the SQL Editor in your Supabase dashboard (not pgAdmin or other tool)

### No default data showing
**Solution:** Run just the INSERT statements from `schema.sql`:
```sql
INSERT INTO public.cafe_tables (table_number, capacity, status) VALUES
  (1, 2, 'available'),
  (2, 4, 'available'),
  ...
```

### Real-time updates not working
**Solution:** Check browser console for errors. The app uses polling (5-second intervals), not WebSockets.

### "User profile not found" error on login
**Solution:** This means the user exists in `auth.users` but not in `public.users`. Recreate the account using the signup form.

## 🗑️ Reset Database (if needed)

⚠️ **WARNING: This deletes ALL data!**

```sql
-- Delete all data (keeps structure)
TRUNCATE users, cafe_tables, menu_items, books, orders, order_items, payments CASCADE;

-- Then re-run the INSERT statements from schema.sql
```

Or completely drop and recreate:
```sql
DROP TABLE IF EXISTS payments CASCADE;
DROP TABLE IF EXISTS order_items CASCADE;
DROP TABLE IF EXISTS orders CASCADE;
DROP TABLE IF EXISTS books CASCADE;
DROP TABLE IF EXISTS menu_items CASCADE;
DROP TABLE IF EXISTS cafe_tables CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- Then re-run the entire schema.sql
```

## 📝 Environment Variables

These are automatically configured in Figma Make:
- ✅ `SUPABASE_URL`
- ✅ `SUPABASE_ANON_KEY`
- ✅ `SUPABASE_SERVICE_ROLE_KEY`
- ✅ `SUPABASE_DB_URL`

## 📚 Additional Resources

- **Database Schema**: `/supabase/migrations/schema.sql`
- **Useful Queries**: `/supabase/migrations/queries.sql`
- **Detailed Setup**: `/DATABASE_SETUP.md`
- **All Changes**: `/CHANGES_SUMMARY.md`

## ✅ Verification Checklist

Before testing, make sure:
- [ ] All 7 tables created in Supabase
- [ ] Default data inserted (6 tables, 8 menu items, 6 books)
- [ ] Can create accounts for all 3 roles
- [ ] Can login with created accounts
- [ ] Customer can place orders
- [ ] Staff can take and update orders
- [ ] Manager can view analytics
- [ ] Real-time updates working (5-second refresh)

## 🎉 You're All Set!

Your Book Cafe Management System is now running with PostgreSQL relational database. Enjoy testing all the features!

If you encounter any issues, check:
1. Browser console for JavaScript errors
2. Supabase logs for server errors
3. Network tab for failed API requests
